"""
SPGF_master.py
==============

Sign-Power Generalized Forecast — Complete Unified Implementation.

Companion to:
  "The Sign-Power Generalized Forecast Functional: A Copula-Theoretic
  Theory of Optimal Nonlinear One-Step Predictors"
  CAIL Working Paper CAIL-WP-2026-SPGF-01

  (c) Dimitrios Thomakos dthomakos@ba.uoa.gr

STRUCTURE
---------
  Module  1  MarginalModel
  Module  2  Copula classes  (_Copula, Gaussian, StudentT, Clayton, Gumbel, Frank, Empirical)
  Module  3  CopulaModel     (auto-selection, unified fitter)
  Module  4  SPGF core       (_sign_power, _ols, _l1_regression, _sign_accuracy_grid,
                               SPGFParams, SPGFEstimator, SPGFForecaster)
  Module  5  Level-domain forecasters   (ThetaForecaster, AR1Forecaster)
  Module  6  Sign forecasters (financial backtest)
             (BuyAndHoldForecaster, AR1SignForecaster, SPGFSignForecaster,
              MultiLagLogisticForecaster, CopulaProbForecaster, EnsembleSignForecaster)
  Module  7  Diagnostic tests (Appendix A)
             (dno_decay_test, hit_rate_bound_test, mse_mae_slope_test,
              jonckheere_terpstra_test, run_diagnostic_tests)
  Module  8  Statistical tests & results
             (pesaran_timmermann_test, diebold_mariano_test, diebold_mariano_sign,
              SignResults, LevelResults)
  Module  9  Data  (fetch_yfinance, prices_to_returns, synthetic_gjr_garch,
                    get_return_series, dgp_ar1_gaussian, dgp_nonlinear_student,
                    dgp_threshold_ar)
  Module 10  Backtest engines (run_sign_backtest, run_level_backtest)
  Module 11  Reporting       (print_* family, _cross_asset_table)
  Module 12  Demo            (run_dgp_demo)
  Module 13  Main            (main)

USAGE
-----
  python SPGF_master.py                    # full financial backtest, real data
  python SPGF_master.py --synthetic        # full backtest, synthetic GJR-GARCH
  python SPGF_master.py --demo             # controlled DGP demo (MSE / MAE / SIGN)
  python SPGF_master.py --fast             # quick smoke-test (reduced data & grid)
  python SPGF_master.py --no-diagnostics  # skip Appendix A tests
  python SPGF_master.py --fallback=zero   # strict zero fallback on prediction failure

UNIFICATION NOTES (differences resolved vs. prior source files)
---------------------------------------------------------------
  1.  CopulaModel (from with_tests) replaces the limited CopulaFitter (from v2),
      which only supported Gaussian and Student-t.  All five families (Gaussian,
      Student-t, Clayton, Gumbel, Frank) plus Empirical are now available
      everywhere, including inside SPGFSignForecaster.

  2.  Monthly-only hardcode removed from main() (was a debug artifact in v2).

  3.  fetch_yfinance default period unified to "5y" (was "1y" in v2 signature).

  4.  diebold_mariano_test is the single implementation for MSE and MAE loss.
      diebold_mariano_sign is a separate function with HAC / normal-distribution
      inference (HLN correction deliberately omitted for binary hit-indicator
      differentials, where the t-distribution approximation is inappropriate).

  5.  SignResults gains forecast_levels (from v2) and fallback_count /
      failure_messages / diagnostics (from with_tests).  All fields coexist.

  6.  Fallback policy is per-forecaster (from with_tests), not a whole-step
      continue (from v2).  This prevents silent observation-count misalignment.

  7.  ThetaForecaster and AR1Forecaster are top-level classes (from standalone),
      not defined inline inside run_dgp_demo.

  8.  LevelResults is a top-level dataclass, not defined inline.

  9.  print_sign_leaderboard alias preserved for backwards compatibility (from v2).

 10.  _DEFAULT_G grid is [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0] everywhere.

 11.  JT test uses raw individual sign observations per bin (not bin means),
      consistent with the corrected LaTeX in the paper.
"""

from __future__ import annotations

import sys
import time
import warnings
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats
from scipy.integrate import quad
from scipy.optimize import brentq, minimize_scalar
from scipy.special import erf, erfinv, expit
from scipy.stats import chi2, norm

warnings.filterwarnings("ignore")


# ======================================================================
# MODULE 1 — MARGINAL MODEL
# ======================================================================

class MarginalModel:
    """Empirical CDF and quantile function via Hazen plotting positions."""

    def __init__(self, x: np.ndarray, smoothing: float = 1e-6):
        x = np.asarray(x, float)
        self._sorted = np.sort(x)
        self.n = x.size
        self._sm = smoothing
        ranks = (np.arange(1, self.n + 1) - 0.5) / self.n
        self._ranks = np.clip(ranks, smoothing, 1 - smoothing)

    def cdf(self, x: np.ndarray) -> np.ndarray:
        x = np.atleast_1d(np.asarray(x, float))
        return np.clip(
            np.interp(x, self._sorted, self._ranks,
                      left=self._sm, right=1 - self._sm),
            self._sm, 1 - self._sm,
        )

    def quantile(self, u: np.ndarray) -> np.ndarray:
        u = np.clip(np.atleast_1d(np.asarray(u, float)), self._sm, 1 - self._sm)
        return np.interp(u, self._ranks, self._sorted)


# ======================================================================
# MODULE 2 — COPULA CLASSES
# ======================================================================

class _Copula:
    name = "abstract"

    def conditional_quantile(self, xi: float, u_prev: float) -> float:
        raise NotImplementedError

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        raise NotImplementedError

    def sample_chain(self, n: int, rng: np.random.Generator,
                     u0: Optional[float] = None) -> np.ndarray:
        u = np.empty(n, dtype=float)
        u[0] = rng.uniform(1e-6, 1 - 1e-6) if u0 is None else float(u0)
        xis = rng.uniform(1e-9, 1 - 1e-9, size=n - 1)
        for i in range(1, n):
            u[i] = self.conditional_quantile(xis[i - 1], u[i - 1])
        return np.clip(u, 1e-9, 1 - 1e-9)


class GaussianCopula(_Copula):
    name = "Gaussian"

    def __init__(self, rho: float):
        self.rho = float(np.clip(rho, -0.999, 0.999))

    @staticmethod
    def _Phi(x: np.ndarray) -> np.ndarray:
        return 0.5 * (1 + erf(x / np.sqrt(2)))

    @staticmethod
    def _Phiinv(p) -> np.ndarray:
        return np.sqrt(2) * erfinv(2 * np.clip(p, 1e-9, 1 - 1e-9) - 1)

    def conditional_quantile(self, xi, u_prev):
        z = self._Phiinv(u_prev)
        sd = np.sqrt(max(1 - self.rho ** 2, 1e-12))
        return float(self._Phi(self.rho * z + sd * self._Phiinv(xi)))

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        z = self._Phiinv(float(u_prev))
        zm = self._Phiinv(float(u_median))
        sd = np.sqrt(max(1 - self.rho ** 2, 1e-12))
        return float(1 - self._Phi((zm - self.rho * z) / sd))

    def power(self, k: int) -> "GaussianCopula":
        return GaussianCopula(self.rho ** k)


class StudentTCopula(_Copula):
    name = "StudentT"

    def __init__(self, rho: float, df: float = 4.0):
        self.rho = float(np.clip(rho, -0.999, 0.999))
        self.df = float(max(df, 2.01))
        self._tdist = stats.t(df=self.df)

    def conditional_quantile(self, xi, u_prev):
        nu = self.df
        t1 = self._tdist.ppf(float(u_prev))
        mu = self.rho * t1
        scale = np.sqrt((nu + t1 ** 2) * (1 - self.rho ** 2) / (nu + 1))
        return float(self._tdist.cdf(mu + scale * stats.t(df=nu + 1).ppf(float(xi))))

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        nu = self.df
        t1 = self._tdist.ppf(float(u_prev))
        tm = self._tdist.ppf(float(u_median))
        mu = self.rho * t1
        scale = np.sqrt((nu + t1 ** 2) * (1 - self.rho ** 2) / (nu + 1))
        return float(1 - stats.t(df=nu + 1).cdf((tm - mu) / max(scale, 1e-12)))

    def power(self, k: int) -> "StudentTCopula":
        return StudentTCopula(self.rho ** k, df=self.df)


class ClaytonCopula(_Copula):
    name = "Clayton"

    def __init__(self, theta: float):
        if theta <= 0:
            raise ValueError("theta > 0 required for Clayton copula")
        self.theta = float(theta)

    def conditional_quantile(self, xi, u_prev):
        th = self.theta
        u = float(np.clip(u_prev, 1e-9, 1 - 1e-9))
        xi = float(np.clip(xi, 1e-9, 1 - 1e-9))
        S = (xi ** (-1.0) * u ** (-(th + 1.0))) ** (th / (th + 1.0))
        v_term = max(S - u ** (-th) + 1.0, 1e-12)
        return float(np.clip(v_term ** (-1.0 / th), 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        th = self.theta
        u = float(np.clip(u_prev, 1e-9, 1 - 1e-9))
        um = float(np.clip(u_median, 1e-9, 1 - 1e-9))
        u_pow = u ** (-th - 1)
        denom = (u ** (-th) + um ** (-th) - 1) ** (-1 / th - 1)
        return float(1 - u_pow * denom)


class GumbelCopula(_Copula):
    name = "Gumbel"

    def __init__(self, theta: float):
        if theta < 1:
            raise ValueError("theta >= 1 required for Gumbel copula")
        self.theta = float(theta)

    def conditional_quantile(self, xi, u_prev):
        u = float(np.clip(u_prev, 1e-9, 1 - 1e-9))
        th = self.theta

        def cond_cdf(v):
            v = float(np.clip(v, 1e-9, 1 - 1e-9))
            lu, lv = -np.log(u), -np.log(v)
            a = lu ** th + lv ** th
            C = np.exp(-a ** (1.0 / th))
            return C * a ** (1.0 / th - 1.0) * lu ** (th - 1.0) / u

        target = float(np.clip(xi, 1e-9, 1 - 1e-9))
        lo, hi = cond_cdf(1e-9), cond_cdf(1 - 1e-9)
        if target <= lo:
            return 1e-9
        if target >= hi:
            return 1 - 1e-9
        try:
            v = brentq(lambda vv: cond_cdf(vv) - target, 1e-9, 1 - 1e-9, xtol=1e-10)
        except ValueError:
            v = 0.5
        return float(np.clip(v, 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        u = float(np.clip(u_prev, 1e-9, 1 - 1e-9))
        um = float(np.clip(u_median, 1e-9, 1 - 1e-9))
        th = self.theta
        lu, lum = -np.log(u), -np.log(um)
        a = lu ** th + lum ** th
        C = np.exp(-a ** (1.0 / th))
        cond_cdf = C * a ** (1.0 / th - 1.0) * lu ** (th - 1.0) / u
        return float(1 - cond_cdf)


class FrankCopula(_Copula):
    name = "Frank"

    def __init__(self, theta: float):
        if abs(theta) < 1e-8:
            raise ValueError("theta != 0 required for Frank copula")
        self.theta = float(theta)

    def conditional_quantile(self, xi, u_prev):
        th = self.theta
        eu = np.exp(-th * float(u_prev))
        xi = float(np.clip(xi, 1e-9, 1 - 1e-9))
        num = xi * (1.0 - eu)
        den = (1.0 - xi) * eu + xi
        den = den if abs(den) > 1e-300 else 1e-300
        v = -np.log(1.0 - num / den) / th
        return float(np.clip(v, 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        th = self.theta
        u = float(np.clip(u_prev, 1e-9, 1 - 1e-9))
        um = float(np.clip(u_median, 1e-9, 1 - 1e-9))
        e_u, e_v, e_1 = np.exp(-th * u), np.exp(-th * um), np.exp(-th)
        num = e_u * (e_v - 1)
        den = (e_1 - 1) + (e_u - 1) * (e_v - 1)
        cond_cdf = num / den if den != 0 else 0.0
        return float(1 - cond_cdf)


class EmpiricalCopula(_Copula):
    name = "Empirical"

    def __init__(self, u: np.ndarray, v: np.ndarray, k: Optional[int] = None):
        self.u = np.asarray(u, dtype=float)
        self.v = np.asarray(v, dtype=float)
        self.n = self.u.size
        self.k = k if k is not None else max(20, int(np.sqrt(self.n)))

    def conditional_quantile(self, xi, u_prev):
        dist = np.abs(self.u - float(u_prev))
        idx = np.argpartition(dist, min(self.k, self.n - 1))[:self.k]
        neighbours = np.sort(self.v[idx])
        pos = float(xi) * (len(neighbours) - 1)
        lo = int(np.floor(pos))
        hi = min(lo + 1, len(neighbours) - 1)
        val = neighbours[lo] * (1 - pos + lo) + neighbours[hi] * (pos - lo)
        return float(np.clip(val, 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, u_prev: float, u_median: float) -> float:
        dist = np.abs(self.u - float(u_prev))
        idx = np.argpartition(dist, min(self.k, self.n - 1))[:self.k]
        return float(np.mean(self.v[idx] > float(u_median)))


# ======================================================================
# MODULE 3 — COPULA MODEL (unified fitter with auto-selection)
# ======================================================================

@dataclass
class CopulaFitResult:
    family: str
    copula: _Copula
    kendall_tau: float
    loglik: Optional[float] = None


class CopulaModel:
    """
    Fits and selects among Gaussian, Student-t, Clayton, Gumbel, Frank, and
    Empirical copulas by pseudo-log-likelihood.  Pass family="auto" (default)
    for automatic selection, or any specific family name to force it.
    """

    def __init__(self, family: str = "auto", student_t_df: float = 4.0):
        self.family = family.lower()
        self.student_t_df = float(student_t_df)
        self.fit_result_: Optional[CopulaFitResult] = None

    def fit(self, x: np.ndarray, marginal: Optional[MarginalModel] = None) -> "CopulaModel":
        x = np.asarray(x, dtype=float)
        if marginal is None:
            marginal = MarginalModel(x)
        u_all = marginal.cdf(x)
        u, v = u_all[:-1], u_all[1:]
        tau, _ = stats.kendalltau(u, v)
        tau = 0.0 if not np.isfinite(tau) else float(np.clip(tau, -0.97, 0.97))
        family = self.family
        if family == "auto":
            family = self._select_family(u, v, tau)
        self.fit_result_ = self._fit_family(family, u, v, tau)
        return self

    def _select_family(self, u: np.ndarray, v: np.ndarray, tau: float) -> str:
        candidates = ["gaussian", "student_t", "frank", "empirical"]
        if tau > 0.02:
            candidates += ["clayton", "gumbel"]
        best_family, best_ll = "gaussian", -np.inf
        for fam in candidates:
            try:
                res = self._fit_family(fam, u, v, tau)
                score = -np.inf if res.loglik is None else res.loglik
                if score > best_ll:
                    best_ll, best_family = score, fam
            except Exception:
                continue
        return best_family

    def _fit_family(self, family: str, u: np.ndarray, v: np.ndarray,
                    tau: float) -> CopulaFitResult:
        rho = float(np.clip(np.sin(tau * np.pi / 2.0), -0.999, 0.999))
        if family == "gaussian":
            cop: _Copula = GaussianCopula(rho)
        elif family == "student_t":
            cop = StudentTCopula(rho, df=self.student_t_df)
        elif family == "clayton":
            theta = max(2 * max(tau, 1e-3) / (1 - max(tau, 1e-3)), 1e-3)
            cop = ClaytonCopula(theta)
        elif family == "gumbel":
            theta = max(1.0 / (1.0 - max(tau, 1e-3)), 1.0 + 1e-6)
            cop = GumbelCopula(theta)
        elif family == "frank":
            cop = FrankCopula(self._frank_theta_from_tau(tau))
        elif family == "empirical":
            cop = EmpiricalCopula(u, v)
        else:
            raise ValueError(f"Unknown copula family: {family!r}")
        ll = self._pseudo_loglik(cop, u, v)
        return CopulaFitResult(family=family, copula=cop, kendall_tau=tau, loglik=ll)

    @staticmethod
    def _frank_theta_from_tau(tau: float) -> float:
        tau = float(np.clip(tau, -0.96, 0.96))
        if abs(tau) < 1e-6:
            return 1e-3

        def debye1(th):
            if abs(th) < 1e-8:
                return 1.0
            val, _ = quad(lambda t: t / np.expm1(t) if abs(t) > 1e-10 else 1.0,
                          0, th, limit=50)
            return val / th

        def tau_of_theta(th):
            return 1.0 - 4.0 / th * (1.0 - debye1(th)) if abs(th) > 1e-8 else 0.0

        try:
            theta = brentq(lambda th: tau_of_theta(th) - tau, -40, 40, xtol=1e-6)
        except ValueError:
            theta = np.sign(tau) * 5.0
        return float(theta) if abs(theta) > 1e-3 else np.sign(tau) * 1e-3

    @staticmethod
    def _pseudo_loglik(cop: _Copula, u: np.ndarray, v: np.ndarray) -> Optional[float]:
        h = 1e-4
        try:
            with np.errstate(all="ignore"):
                q_lo = np.array([cop.conditional_quantile(max(vv - h, 1e-9), up)
                                 for vv, up in zip(v, u)])
                q_hi = np.array([cop.conditional_quantile(min(vv + h, 1 - 1e-9), up)
                                 for vv, up in zip(v, u)])
                dvdxi = np.clip(np.abs((q_hi - q_lo) / (2 * h)), 1e-8, 1e8)
                ll = -np.log(dvdxi)
                ll = ll[np.isfinite(ll)]
                return float(np.mean(ll)) if ll.size > 0 else None
        except Exception:
            return None

    def sample_chain(self, n: int, rng: Optional[np.random.Generator] = None,
                     u0: Optional[float] = None) -> np.ndarray:
        if self.fit_result_ is None:
            raise RuntimeError("Call .fit(x) before .sample_chain()")
        rng = rng or np.random.default_rng()
        return self.fit_result_.copula.sample_chain(n, rng, u0=u0)

    def __repr__(self) -> str:
        if self.fit_result_ is None:
            return f"CopulaModel(family={self.family!r}, unfitted)"
        r = self.fit_result_
        return f"CopulaModel(family={r.family!r}, tau={r.kendall_tau:.3f})"


# ======================================================================
# MODULE 4 — SPGF CORE
# ======================================================================

def _sign_power(x: np.ndarray, g: float) -> np.ndarray:
    """Sign-power transform: sgn(x)|x|^g."""
    return np.sign(x) * (np.abs(x) ** g)


def _ols(z: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """OLS regression of y on z; returns (intercept, slope)."""
    z_m, y_m = z.mean(), y.mean()
    denom = float(np.dot(z - z_m, z - z_m))
    if denom < 1e-12:
        return float(y_m), 0.0
    b = float(np.dot(y - y_m, z - z_m) / denom)
    return float(y_m - b * z_m), b


def _l1_regression(z: np.ndarray, y: np.ndarray,
                   max_iter: int = 50, tol: float = 1e-6) -> Tuple[float, float]:
    """Weighted median (L1 / MAE) regression of y on z; returns (intercept, slope)."""
    a, b = _ols(z, y)
    eps = 1e-8 * (np.std(y) + 1e-8)
    for _ in range(max_iter):
        a_new = float(np.median(y - b * z))
        nz = np.abs(z) > eps
        if nz.sum() < 2:
            b_new = 0.0
        else:
            ratios = (y[nz] - a_new) / z[nz]
            weights = np.abs(z[nz])
            order = np.argsort(ratios)
            w_cum = np.cumsum(weights[order])
            idx = min(np.searchsorted(w_cum, w_cum[-1] / 2.0), len(ratios) - 1)
            b_new = float(ratios[order[idx]])
        if abs(a_new - a) + abs(b_new - b) < tol:
            a, b = a_new, b_new
            break
        a, b = a_new, b_new
    return a, b


def _sign_accuracy_grid(y: np.ndarray, z: np.ndarray,
                        tau_grid: np.ndarray) -> Tuple[float, float, float]:
    """Grid search for the threshold tau* maximising sign accuracy."""
    sy = np.sign(y)
    sy[sy == 0] = 1
    best_acc, best_tau, best_sb = -np.inf, 0.0, 1.0
    for tau in tau_grid:
        sz = np.sign(z - tau)
        sz[sz == 0] = 1
        psi = float(np.mean(sy * sz))
        acc_pos = 0.5 + 0.5 * psi
        acc_neg = 0.5 - 0.5 * psi
        if acc_pos >= acc_neg and acc_pos > best_acc:
            best_acc, best_tau, best_sb = acc_pos, float(tau), 1.0
        elif acc_neg > acc_pos and acc_neg > best_acc:
            best_acc, best_tau, best_sb = acc_neg, float(tau), -1.0
    return best_tau, best_acc, best_sb


@dataclass
class SPGFParams:
    """
    Fitted SPGF parameters for a given loss criterion.

    For loss == "MSE" or "MAE":
        forecast(x_lag) returns a level prediction  a + b·sgn(x)|x|^g.
        predict_sign returns sign of that level.
        predict_prob returns a continuous probability proxy via a sigmoid squash.

    For loss == "SIGN":
        forecast(x_lag) returns  sb·(x_lag - tau)  (the signed margin).
        predict_sign returns sign of that margin directly.
        predict_prob returns a sigmoid-squashed probability from the margin.
    """
    a: float
    b: float
    d: int
    g: float
    tau: Optional[float]
    loss: str
    value: float

    def forecast(self, x_lag: float) -> float:
        """Raw level forecast:  a + b·sgn(x_lag)|x_lag|^g."""
        z = np.sign(x_lag) * (abs(x_lag) ** self.g)
        return self.a + self.b * z

    def predict_sign(self, x_lag: float) -> int:
        """
        Directional prediction (+1 / -1).

        For MSE/MAE:  sign of the level forecast a + b·z.
        For SIGN:     sign of the margin sb·(x_lag - tau), equivalent
                      to sign(forecast) since a = -sb·tau, b = sb.
        """
        raw = self.forecast(x_lag)
        return int(np.sign(raw)) if raw != 0 else 1

    def predict_prob(self, x_lag: float) -> float:
        """
        Probability that the next observation is positive.

        Produced by squashing the raw forecast through a logistic function
        scaled by the in-sample standard deviation of z.  This is a
        monotone transformation and preserves the sign decision exactly.
        For MSE/MAE the scale is meaningful (units of y); for SIGN the
        margin has no natural scale so we use a fixed unit scale.
        """
        raw = self.forecast(x_lag)
        # Scale-free squash: map raw margin to (0,1).
        # expit(2*raw) gives 0.75 at raw=+1, 0.25 at raw=-1 — a mild calibration.
        return float(expit(2.0 * raw))


class SPGFEstimator:
    """
    Searches (d, g) to minimise MSE / MAE or maximise SIGN accuracy
    on a simulated Markov chain drawn from the fitted copula.
    """
    _DEFAULT_G = np.array([0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0])

    def __init__(self, marginal: MarginalModel, copula: CopulaModel,
                 d_max: int = 4, g_grid: Optional[np.ndarray] = None,
                 n_sim: int = 50_000, tau_n_grid: int = 200,
                 rng: Optional[np.random.Generator] = None):
        self.marginal = marginal
        self.copula = copula
        self.d_max = int(d_max)
        self.g_grid = np.asarray(
            g_grid if g_grid is not None else self._DEFAULT_G, dtype=float)
        self.n_sim = int(n_sim)
        self.tau_n_grid = int(tau_n_grid)
        self.rng = rng or np.random.default_rng()
        self.params_mse_: Optional[SPGFParams] = None
        self.params_mae_: Optional[SPGFParams] = None
        self.params_sign_: Optional[SPGFParams] = None

    def fit(self, verbose: bool = False) -> "SPGFEstimator":
        chain_len = self.n_sim + self.d_max + 1
        if verbose:
            print(f" [SPGF] simulating chain ({chain_len:,}) ...", end=" ", flush=True)
        u_chain = self.copula.sample_chain(chain_len, rng=self.rng)
        x_chain = self.marginal.quantile(u_chain)
        if verbose:
            print("done.")

        n = self.n_sim
        best: Dict[str, dict] = {
            "MSE": {"value": np.inf, "params": None},
            "MAE": {"value": np.inf, "params": None},
            "SIGN": {"value": -np.inf, "params": None},
        }

        for d in range(self.d_max + 1):
            y = x_chain[d + 1: d + 1 + n]
            x_lag = x_chain[:n]
            for g in self.g_grid:
                z = _sign_power(x_lag, g)

                # MSE
                a_m, b_m = _ols(z, y)
                mse_val = float(np.mean((y - a_m - b_m * z) ** 2))
                if mse_val < best["MSE"]["value"]:
                    best["MSE"].update(value=mse_val,
                                       params=SPGFParams(a=a_m, b=b_m, d=d, g=g,
                                                         tau=None, loss="MSE",
                                                         value=mse_val))

                # MAE
                a_l, b_l = _l1_regression(z, y)
                mae_val = float(np.mean(np.abs(y - a_l - b_l * z)))
                if mae_val < best["MAE"]["value"]:
                    best["MAE"].update(value=mae_val,
                                       params=SPGFParams(a=a_l, b=b_l, d=d, g=g,
                                                         tau=None, loss="MAE",
                                                         value=mae_val))

                # SIGN
                tau_grid = np.quantile(z, np.linspace(0.02, 0.98, self.tau_n_grid))
                tau_s, acc_s, sb_s = _sign_accuracy_grid(y, z, tau_grid)
                if acc_s > best["SIGN"]["value"]:
                    best["SIGN"].update(value=acc_s,
                                        params=SPGFParams(a=-sb_s * tau_s, b=sb_s,
                                                          d=d, g=g, tau=tau_s,
                                                          loss="SIGN", value=acc_s))

        self.params_mse_ = best["MSE"]["params"]
        self.params_mae_ = best["MAE"]["params"]
        sp = best["SIGN"]["params"]
        # Per g-invariance theorem: SIGN is flat in g, so inherit MSE-optimal g.
        if sp is not None and self.params_mse_ is not None:
            sp.g = self.params_mse_.g
        self.params_sign_ = sp
        return self

    def summary(self) -> Dict[str, Optional[SPGFParams]]:
        return {"MSE": self.params_mse_,
                "MAE": self.params_mae_,
                "SIGN": self.params_sign_}


class SPGFForecaster:
    """
    Full SPGF predictor for a given loss (MSE, MAE, or SIGN).

    Fits MarginalModel → CopulaModel → SPGFEstimator in one call and
    exposes a unified interface for both level-domain and sign-domain use:

        predict(x_context)       → float  level forecast  a + b·z
        predict_sign(x_context)  → int    +1 / -1
        predict_prob(x_context)  → float  P(next > 0)  in (0,1)

    This makes SPGFForecaster a drop-in replacement for *both*
    the level-domain forecasters (ThetaForecaster, AR1Forecaster) used in
    run_level_backtest() and the sign-domain forecasters
    (AR1SignForecaster, CopulaProbForecaster …) used in run_sign_backtest().

    Parameter notes
    ---------------
    loss : "MSE"  — minimise E[(y - a - b·z)²] over (a, b, d, g)
           "MAE"  — minimise E[|y - a - b·z|]  over (a, b, d, g)
           "SIGN" — maximise directional accuracy over (a/b≡tau, d, g)
                    g is inherited from the MSE-optimal g (g-invariance thm).
    """

    def __init__(self, loss: str = "MSE", copula_family: str = "auto",
                 d_max: int = 4, g_grid: Optional[np.ndarray] = None,
                 n_sim: int = 50_000, student_t_df: float = 4.0):
        self.loss = loss.upper()
        self.copula_family = copula_family
        self.d_max = d_max
        self.g_grid = g_grid
        self.n_sim = n_sim
        self.student_t_df = student_t_df
        self._params: Optional[SPGFParams] = None

    # ------------------------------------------------------------------
    # Fitting
    # ------------------------------------------------------------------

    def fit(self, x_train: np.ndarray,
            rng: Optional[np.random.Generator] = None) -> "SPGFForecaster":
        x_train = np.asarray(x_train, dtype=float)
        rng = rng or np.random.default_rng()
        marginal = MarginalModel(x_train)
        copula = CopulaModel(family=self.copula_family,
                             student_t_df=self.student_t_df)
        copula.fit(x_train, marginal=marginal)
        est = SPGFEstimator(marginal, copula, d_max=self.d_max,
                            g_grid=self.g_grid, n_sim=self.n_sim, rng=rng)
        est.fit(verbose=False)
        self._params = est.summary()[self.loss]
        return self

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _x_lag(self, x_context: np.ndarray) -> float:
        """Extract the correct lagged observation for the fitted d."""
        if self._params is None:
            raise RuntimeError("Call .fit() before predicting.")
        d = self._params.d
        idx = -(d + 1)
        return (float(x_context[idx])
                if abs(idx) <= len(x_context)
                else float(x_context[0]))

    # ------------------------------------------------------------------
    # Prediction interface (level + sign + probability)
    # ------------------------------------------------------------------

    def predict(self, x_context: np.ndarray) -> float:
        """
        Level-domain forecast  f(x_lag) = a + b·sgn(x_lag)|x_lag|^g.

        For MSE/MAE this is the optimal point forecast under the fitted loss.
        For SIGN this is the signed margin sb·(x_lag - tau); its sign gives
        the direction, but the absolute value is not a calibrated level.
        Use predict_sign() / predict_prob() for directional tasks with SIGN.
        """
        return self._params.forecast(self._x_lag(x_context))

    def predict_sign(self, x_context: np.ndarray) -> int:
        """Directional prediction (+1 or -1)."""
        return self._params.predict_sign(self._x_lag(x_context))

    def predict_prob(self, x_context: np.ndarray) -> float:
        """Probability that the next observation is positive, in (0, 1)."""
        return self._params.predict_prob(self._x_lag(x_context))

    @property
    def params(self) -> Optional[SPGFParams]:
        return self._params


# ======================================================================
# MODULE 5 — LEVEL-DOMAIN FORECASTERS (for DGP demo)
# ======================================================================

class ThetaForecaster:
    """Theta method: linear trend + SES (Assimakopoulos & Nikolopoulos, 2000)."""

    def __init__(self, alpha: Optional[float] = None):
        self.alpha = alpha
        self._a = 0.0
        self._b = 0.0
        self._ses_next = 0.0
        self._n = 0

    def fit(self, x_train: np.ndarray, rng=None) -> "ThetaForecaster":
        x = np.asarray(x_train, dtype=float)
        n = len(x)
        self._n = n
        t = np.arange(1, n + 1, dtype=float)
        t_m, x_m = t.mean(), x.mean()
        b = np.dot(t - t_m, x - x_m) / np.dot(t - t_m, t - t_m)
        a = x_m - b * t_m
        self._a, self._b = float(a), float(b)
        theta2 = 2.0 * x - (a + b * t)
        alpha = self.alpha if self.alpha is not None else self._fit_alpha(theta2)
        level = float(theta2[0])
        for i in range(1, n):
            level = alpha * theta2[i] + (1.0 - alpha) * level
        self._ses_next = float(level)
        return self

    @staticmethod
    def _fit_alpha(y: np.ndarray) -> float:
        def sse(alpha):
            level, s = y[0], 0.0
            for i in range(1, len(y)):
                s += (y[i] - level) ** 2
                level = alpha * y[i] + (1.0 - alpha) * level
            return s
        res = minimize_scalar(sse, bounds=(0.01, 0.99), method="bounded")
        return float(res.x)

    def predict(self, x_context: np.ndarray) -> float:
        return 0.5 * (self._a + self._b * (self._n + 1)) + 0.5 * self._ses_next


class AR1Forecaster:
    """Demeaned AR(1) level-domain forecast."""

    def __init__(self, demean: bool = True):
        self.demean = demean
        self._a = 0.0
        self._b = 0.0

    def fit(self, x_train: np.ndarray, rng=None) -> "AR1Forecaster":
        x = np.asarray(x_train, dtype=float)
        y, z = x[1:], x[:-1]
        if self.demean:
            zm, ym = z.mean(), y.mean()
            denom = float(np.dot(z - zm, z - zm))
            if denom < 1e-12:
                self._b, self._a = 0.0, float(y.mean())
            else:
                self._b = float(np.dot(y - ym, z - zm) / denom)
                self._a = float(ym - self._b * zm)
        else:
            denom = float(np.dot(z, z))
            self._b = float(np.dot(y, z) / denom) if denom > 1e-12 else 0.0
            self._a = 0.0
        return self

    def predict(self, x_context: np.ndarray) -> float:
        return self._a + self._b * float(x_context[-1])


# ======================================================================
# MODULE 6 — SIGN FORECASTERS (financial backtest)
# ======================================================================

class BuyAndHoldForecaster:
    """Always predicts positive return.  Passive long-only benchmark."""

    def fit(self, x: np.ndarray) -> "BuyAndHoldForecaster":
        return self

    def predict_sign(self, x_context: np.ndarray) -> int:
        return 1

    def predict_prob(self, x_context) -> float:
        return 0.75


class AR1SignForecaster:
    """sign(a + b*x_t) where (a, b) are fitted by OLS."""

    def __init__(self):
        self._a = 0.0
        self._b = 0.0

    def fit(self, x: np.ndarray) -> "AR1SignForecaster":
        y, z = x[1:], x[:-1]
        zm, ym = z.mean(), y.mean()
        denom = float(np.dot(z - zm, z - zm))
        self._b = float(np.dot(y - ym, z - zm) / denom) if denom > 1e-12 else 0.0
        self._a = float(ym - self._b * zm)
        return self

    def predict_prob(self, x_last: float) -> float:
        return 0.75 if self._a + self._b * float(x_last) > 0 else 0.25

    def predict_sign(self, x_last: float) -> int:
        return 1 if self._a + self._b * float(x_last) > 0 else -1


class SPGFSignForecaster:
    """SPGF-Sign: tau* from copula simulation over the full five-family menu."""

    def __init__(self, d_max: int = 4, n_sim: int = 20_000,
                 tau_n_grid: int = 200, copula_family: str = "auto"):
        self.d_max = d_max
        self.n_sim = n_sim
        self.tau_n_grid = tau_n_grid
        self.copula_family = copula_family
        self._tau = 0.0
        self._sb = 1.0
        self._d = 0
        self._acc = 0.5

    def fit(self, x: np.ndarray,
            rng: Optional[np.random.Generator] = None) -> "SPGFSignForecaster":
        rng = rng or np.random.default_rng()
        marginal = MarginalModel(x)
        copula_model = CopulaModel(family=self.copula_family)
        copula_model.fit(x, marginal)
        self._fitted_marginal = marginal
        self._fitted_copula = copula_model
        chain_len = self.n_sim + self.d_max + 1
        u_chain = copula_model.sample_chain(chain_len, rng)
        x_chain = marginal.quantile(u_chain)
        n = self.n_sim
        best_acc, best_tau, best_sb, best_d = -np.inf, 0.0, 1.0, 0
        for d in range(self.d_max + 1):
            y = x_chain[d + 1: d + 1 + n]
            z = x_chain[:n]
            sy = np.sign(y)
            tau_grid = np.quantile(z, np.linspace(0.02, 0.98, self.tau_n_grid))
            for tau in tau_grid:
                sz = np.sign(z - tau)
                psi = float(np.mean(sy * sz))
                for sb, acc in [(1.0, 0.5 + 0.5 * psi), (-1.0, 0.5 - 0.5 * psi)]:
                    if acc > best_acc:
                        best_acc, best_tau, best_sb, best_d = acc, float(tau), sb, d
        self._tau, self._sb, self._d, self._acc = best_tau, best_sb, best_d, best_acc
        return self

    def predict_sign(self, x_context: np.ndarray) -> int:
        idx = -(self._d + 1)
        x_lag = (float(x_context[idx])
                 if abs(idx) <= len(x_context)
                 else float(x_context[0]))
        return int(np.sign(self._sb * (x_lag - self._tau))) or 1

    def predict_prob(self, x_context: np.ndarray) -> float:
        return 0.75 if self.predict_sign(x_context) == 1 else 0.25


class MultiLagLogisticForecaster:
    """Logistic regression of sign(r_{t+1}) on d_max lagged signs."""

    def __init__(self, d_max: int = 5, lam: float = 1.0,
                 max_iter: int = 30, tol: float = 1e-7):
        self.d_max = d_max
        self.lam = lam
        self.max_iter = max_iter
        self.tol = tol
        self._beta: Optional[np.ndarray] = None

    def _build_X(self, x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        n, D = len(x), self.d_max
        rows = n - D - 1
        if rows <= 0:
            raise ValueError("Series too short for d_max")
        X = np.ones((rows, D + 2))
        for d in range(D + 1):
            X[:, d + 1] = np.sign(x[D - d: D - d + rows])
        y_bin = (x[D + 1: D + 1 + rows] > 0).astype(float)
        return X, y_bin

    def fit(self, x: np.ndarray) -> "MultiLagLogisticForecaster":
        X, y = self._build_X(x)
        _, p = X.shape
        beta = np.zeros(p)
        lam = self.lam
        for _ in range(self.max_iter):
            p_hat = np.clip(expit(X @ beta), 1e-9, 1 - 1e-9)
            W = p_hat * (1 - p_hat)
            grad = X.T @ (y - p_hat) - lam * beta
            grad[0] += lam * beta[0]
            H = -(X.T * W) @ X - lam * np.eye(p)
            H[0, 0] += lam
            try:
                delta = np.linalg.solve(H, grad)
            except np.linalg.LinAlgError:
                break
            beta -= delta
            if np.max(np.abs(delta)) < self.tol:
                break
        self._beta = beta
        return self

    def predict_prob(self, x_context: np.ndarray) -> float:
        D = self.d_max
        ctx = x_context
        if len(ctx) < D + 1:
            ctx = np.concatenate([np.zeros(D + 1 - len(ctx)), ctx])
        feat = np.array([1.0] + [np.sign(float(ctx[-(d + 1)])) for d in range(D + 1)])
        return float(expit(self._beta @ feat)) if self._beta is not None else 0.5

    def predict_sign(self, x_context: np.ndarray) -> int:
        return 1 if self.predict_prob(x_context) >= 0.5 else -1


class CopulaProbForecaster:
    """P(r_{t+1} > 0 | r_t) directly from the fitted copula (h(u_0 | u))."""

    def __init__(self, use_parametric: bool = True):
        self.use_parametric = use_parametric
        self._fitter: Optional[CopulaModel] = None
        self._marginal: Optional[MarginalModel] = None
        self._u_median = 0.5

    def fit(self, x: np.ndarray) -> "CopulaProbForecaster":
        self._marginal = MarginalModel(x)
        self._fitter = CopulaModel(family="auto")
        self._fitter.fit(x, self._marginal)
        # u_0 = F(0): the copula coordinate corresponding to the zero threshold
        self._u_median = float(self._marginal.cdf(np.array([0.0]))[0])
        return self

    def predict_prob(self, x_context: np.ndarray) -> float:
        x_last = float(x_context[-1])
        u_last = float(self._marginal.cdf(np.array([x_last]))[0])
        return self._fitter.fit_result_.copula.cond_prob_positive(u_last, self._u_median)

    def predict_sign(self, x_context: np.ndarray) -> int:
        return 1 if self.predict_prob(x_context) >= 0.5 else -1


class EnsembleSignForecaster:
    """Majority-vote ensemble of the four active forecasters.  Ties broken by CopulaProb."""

    def __init__(self, ar1: AR1SignForecaster, spgf: SPGFSignForecaster,
                 multilag: MultiLagLogisticForecaster, copula_prob: CopulaProbForecaster):
        self._ar1 = ar1
        self._spgf = spgf
        self._multilag = multilag
        self._cp = copula_prob

    def predict_prob(self, x_context: np.ndarray) -> float:
        p1 = self._ar1.predict_prob(float(x_context[-1]))
        p2 = self._spgf.predict_prob(x_context)
        p3 = self._multilag.predict_prob(x_context)
        p4 = self._cp.predict_prob(x_context)
        return float(np.mean([p1, p2, p3, p4]))

    def predict_sign(self, x_context: np.ndarray) -> int:
        votes = [
            self._ar1.predict_sign(float(x_context[-1])),
            self._spgf.predict_sign(x_context),
            self._multilag.predict_sign(x_context),
            self._cp.predict_sign(x_context),
        ]
        total = sum(votes)
        if total > 0:
            return 1
        if total < 0:
            return -1
        return self._cp.predict_sign(x_context)  # CopulaProb breaks ties


# ======================================================================
# MODULE 7 — DIAGNOSTIC TESTS (Appendix A)
# ======================================================================

def dno_decay_test(x: np.ndarray, d_max: int = 5, n_sim: int = 20_000,
                   rng_seed: int = 42) -> Dict[str, float]:
    """
    Wald test for DNO concordance decay (Appendix A, test A.1).
    H0: empirical concordance at each lag equals the DNO-implied value.
    Returns {'stat': W, 'pvalue': p, 'df': d_max} under chi2_{d_max}.
    """
    T = len(x)
    if T < d_max + 2:
        return {"stat": np.nan, "pvalue": np.nan, "df": d_max}
    rng = np.random.default_rng(rng_seed)
    marginal = MarginalModel(x)
    copula_model = CopulaModel(family="auto")
    copula_model.fit(x, marginal)
    chain_len = n_sim + d_max + 1
    u_chain = copula_model.sample_chain(chain_len, rng)
    x_chain = marginal.quantile(u_chain)

    sim_conc = np.array([
        float(np.mean(np.sign(x_chain[d + 1: d + 1 + n_sim]) *
                      np.sign(x_chain[:n_sim])))
        for d in range(d_max)
    ])
    emp_conc = np.array([
        float(np.mean(np.sign(x[d + 1:]) * np.sign(x[:len(x) - d - 1])))
        for d in range(d_max)
    ])
    e_vec = emp_conc - sim_conc

    n_boot = 200
    block_size = max(1, int(np.sqrt(T)))
    boot_diff = np.zeros((n_boot, d_max))
    for b in range(n_boot):
        n_blocks = int(np.ceil(T / block_size))
        boot_idx: List[int] = []
        for _ in range(n_blocks):
            start = int(rng.integers(0, T - block_size + 1))
            boot_idx.extend(range(start, min(start + block_size, T)))
        x_boot = x[np.array(boot_idx[:T])]
        boot_diff[b] = np.array([
            float(np.mean(np.sign(x_boot[d + 1:]) * np.sign(x_boot[:len(x_boot) - d - 1])))
            - sim_conc[d]
            for d in range(d_max)
        ])

    cov_mat = np.cov(boot_diff, rowvar=False)
    if np.linalg.cond(cov_mat) > 1e12:
        cov_mat += np.eye(d_max) * 1e-6
    try:
        W = float(e_vec @ np.linalg.inv(cov_mat) @ e_vec)
        p = float(1 - chi2.cdf(W, d_max))
    except np.linalg.LinAlgError:
        W, p = np.nan, np.nan
    return {"stat": W, "pvalue": p, "df": d_max}


def hit_rate_bound_test(sign_results: "SignResults",
                        kappa: float) -> Dict[str, float]:
    """
    One-sided Z-test: H0: HR <= 0.5 + 0.5|kappa| (Appendix A, test A.2).
    Returns {'stat': Z, 'pvalue': p}.
    """
    hr = sign_results.hit_rate
    if np.isnan(hr) or np.isnan(kappa):
        return {"stat": np.nan, "pvalue": np.nan}
    n_obs = len(sign_results.actual_returns)
    if n_obs < 10:
        return {"stat": np.nan, "pvalue": np.nan}
    bound = 0.5 + 0.5 * abs(kappa)
    rng = np.random.default_rng(42)
    boot_deltas = []
    for _ in range(200):
        idx = rng.choice(n_obs, size=n_obs, replace=True)
        hr_b = float(np.mean(
            np.array(sign_results.predicted_signs)[idx] ==
            np.array(sign_results.actual_signs)[idx]
        ))
        boot_deltas.append(hr_b - bound)
    se = np.std(boot_deltas, ddof=1)
    if se < 1e-10:
        return {"stat": 0.0, "pvalue": 1.0}
    Z = (hr - bound) / se
    return {"stat": float(Z), "pvalue": float(1 - norm.cdf(Z))}


def mse_mae_slope_test(y: np.ndarray, z: np.ndarray) -> Dict[str, float]:
    """
    Hausman-type test for equality of MSE and MAE slopes (Appendix A, test A.3).
    H0: b_MSE = b_MAE.  Returns {'stat': W, 'pvalue': p} under chi2_1.
    """
    y, z = np.asarray(y, float), np.asarray(z, float)
    if len(y) < 10:
        return {"stat": np.nan, "pvalue": np.nan}
    zm, ym = z.mean(), y.mean()
    denom = float(np.dot(z - zm, z - zm))
    if denom < 1e-12:
        return {"stat": np.nan, "pvalue": np.nan}
    b_mse = float(np.dot(y - ym, z - zm) / denom)
    _, b_mae = _l1_regression(z, y)
    n = len(y)
    rng = np.random.default_rng(42)
    boot_diffs = []
    for _ in range(200):
        idx = rng.choice(n, size=n, replace=True)
        yb, zb = y[idx], z[idx]
        zmb, ymb = zb.mean(), yb.mean()
        denb = float(np.dot(zb - zmb, zb - zmb))
        if denb < 1e-12:
            continue
        b_mse_b = float(np.dot(yb - ymb, zb - zmb) / denb)
        _, b_mae_b = _l1_regression(zb, yb)
        boot_diffs.append(b_mse_b - b_mae_b)
    if len(boot_diffs) < 10:
        return {"stat": np.nan, "pvalue": np.nan}
    q = b_mse - b_mae
    var_q = np.var(boot_diffs, ddof=1)
    if var_q < 1e-12:
        return {"stat": 0.0, "pvalue": 1.0}
    W = q ** 2 / var_q
    return {"stat": float(W), "pvalue": float(1 - chi2.cdf(W, 1))}


def jonckheere_terpstra_test(x: np.ndarray, y: np.ndarray,
                              n_bins: int = 10) -> Dict[str, float]:
    """
    Jonckheere-Terpstra test for monotone sign-monotonicity (Appendix A, test A.4).
    H0: no monotonic trend in E[sign(y) | x].  Two-sided normal approximation.
    Operates on raw individual observations within each bin, as per the corrected
    paper formula.  Returns {'stat': Z, 'pvalue': p}.
    """
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < n_bins * 2:
        return {"stat": np.nan, "pvalue": np.nan}
    bins = np.percentile(x, np.linspace(0, 100, n_bins + 1))
    bin_indices = np.digitize(x, bins[1:-1])
    groups = []
    for i in range(n_bins):
        mask = bin_indices == i
        if mask.sum() < 2:
            return {"stat": np.nan, "pvalue": np.nan}
        # Raw individual sign observations per bin — not bin averages.
        groups.append(np.sign(y[mask]))
    J = 0
    for i in range(n_bins):
        for j in range(i + 1, n_bins):
            for val_i in groups[i]:
                for val_j in groups[j]:
                    if val_i <= val_j:
                        J += 1
    N = sum(len(g) for g in groups)
    sum_ni2 = sum(len(g) ** 2 for g in groups)
    E_J = (N ** 2 - sum_ni2) / 4.0
    var_J = (N ** 2 * (2 * N + 3) -
             sum(len(g) ** 2 * (2 * len(g) + 3) for g in groups)) / 72.0
    if var_J <= 0:
        return {"stat": 0.0, "pvalue": 1.0}
    Z = (J - E_J) / np.sqrt(var_J)
    return {"stat": float(Z), "pvalue": float(2 * (1 - norm.cdf(abs(Z))))}


def run_diagnostic_tests(x: np.ndarray, sign_results: "SignResults",
                         d_max: int = 5) -> Dict[str, Dict[str, float]]:
    """Run all four Appendix A diagnostic tests and return a results dict."""
    out: Dict[str, Dict[str, float]] = {}
    out["DNO"] = dno_decay_test(x, d_max=d_max)
    kappa = float(np.mean(np.sign(x[1:]) * np.sign(x[:-1]))) if len(x) > 2 else 0.0
    out["HitBound"] = hit_rate_bound_test(sign_results, kappa)
    if len(x) > 1:
        out["MSEvsMAE"] = mse_mae_slope_test(x[1:], x[:-1])
    else:
        out["MSEvsMAE"] = {"stat": np.nan, "pvalue": np.nan}
    if len(x) > 20:
        out["Monotonicity"] = jonckheere_terpstra_test(x[:-1], x[1:])
    else:
        out["Monotonicity"] = {"stat": np.nan, "pvalue": np.nan}
    return out


# ======================================================================
# MODULE 8 — STATISTICAL TESTS & RESULTS
# ======================================================================

def pesaran_timmermann_test(actual: np.ndarray,
                            forecast: np.ndarray) -> Tuple[float, float]:
    """
    Pesaran-Timmermann (1992) directional accuracy test.
    Returns (PT_stat, two-sided p-value).
    Variance formulas: Var(p_hat) = p_c(1-p_c)/n,
    Var(p_c) = ((2p_y-1)^2 p_f(1-p_f) + (2p_f-1)^2 p_y(1-p_y)) / n.
    """
    actual = np.asarray(actual, float)
    forecast = np.asarray(forecast, float)
    n = len(actual)
    if n < 5:
        return 0.0, 1.0
    s_a = (actual > 0).astype(float)
    s_f = (forecast > 0).astype(float)
    p_y, p_f = s_a.mean(), s_f.mean()
    p_c = p_y * p_f + (1 - p_y) * (1 - p_f)
    p_hat = np.mean(s_a == s_f)
    var_p_c = ((2 * p_y - 1) ** 2 * p_f * (1 - p_f) +
               (2 * p_f - 1) ** 2 * p_y * (1 - p_y)) / max(n, 1)
    var_p_hat = p_c * (1 - p_c) / max(n, 1)
    var_diff = var_p_hat - var_p_c
    if var_diff <= 0:
        return 0.0, 1.0
    pt_stat = (p_hat - p_c) / np.sqrt(var_diff)
    return float(pt_stat), float(2 * stats.norm.sf(abs(pt_stat)))


def diebold_mariano_test(e1: np.ndarray, e2: np.ndarray,
                         loss: str = "MSE", h: int = 1,
                         correction: bool = True) -> Tuple[float, float]:
    """
    HLN-corrected Diebold-Mariano test for MSE or MAE loss.
    Positive DM means e1 has larger loss than e2 (e1 is worse).
    Returns (DM_stat, two-sided p-value) using t(T-1) distribution.
    """
    e1, e2 = np.asarray(e1, float), np.asarray(e2, float)
    loss_u = loss.upper()
    if loss_u == "MSE":
        d = e1 ** 2 - e2 ** 2
    elif loss_u == "MAE":
        d = np.abs(e1) - np.abs(e2)
    else:
        raise ValueError("loss must be 'MSE' or 'MAE' for diebold_mariano_test")
    T = len(d)
    if T < 5:
        return 0.0, 1.0
    d_bar = d.mean()
    bw = max(1, int(np.ceil(T ** (1.0 / 3.0))))
    g0 = np.var(d, ddof=0)
    g_sum = sum(
        2 * (1 - j / (bw + 1.0)) * float(np.cov(d[j:], d[:-j], ddof=0)[0, 1])
        for j in range(1, bw + 1)
    )
    var_d = (g0 + g_sum) / T
    if var_d <= 0:
        return 0.0, 1.0
    dm = d_bar / np.sqrt(var_d)
    if correction:
        dm *= np.sqrt((T + 1 - 2 * h + h * (h - 1) / T) / T)
    pv = float(2.0 * stats.t(df=T - 1).sf(abs(dm)))
    return float(dm), pv


def diebold_mariano_sign(hits1: np.ndarray,
                         hits2: np.ndarray) -> Tuple[float, float]:
    """
    DM-style test for directional accuracy comparison on binary hit indicators.
    Uses HAC variance with normal (not t) distribution — HLN correction is
    inappropriate for binary hit differentials.
    Positive stat means hits1 has better directional accuracy than hits2.
    Returns (DM_stat, two-sided p-value).
    """
    h1, h2 = np.asarray(hits1, float), np.asarray(hits2, float)
    d = h1 - h2
    T = len(d)
    if T < 5:
        return 0.0, 1.0
    d_bar = d.mean()
    bw = max(1, int(np.ceil(T ** (1.0 / 3.0))))
    g0 = np.var(d, ddof=0)
    g_sum = sum(
        2 * (1 - j / (bw + 1.0)) * float(np.cov(d[j:], d[:-j], ddof=0)[0, 1])
        for j in range(1, bw + 1)
    )
    var_d = (g0 + g_sum) / T
    if var_d <= 0:
        return 0.0, 1.0
    dm = d_bar / np.sqrt(var_d)
    return float(dm), float(2.0 * stats.norm.sf(abs(dm)))


@dataclass
class SignResults:
    """Stores predictions, actuals, errors, and optional diagnostics for one forecaster."""
    name: str
    predicted_signs: List[int] = field(default_factory=list)
    predicted_probs: List[float] = field(default_factory=list)
    forecast_levels: List[float] = field(default_factory=list)
    actual_returns: List[float] = field(default_factory=list)
    actual_signs: List[int] = field(default_factory=list)
    errors: List[float] = field(default_factory=list)
    fallback_count: int = 0
    failure_messages: List[str] = field(default_factory=list)
    diagnostics: List[Dict[str, Dict[str, float]]] = field(default_factory=list)

    def append(self, pred_sign: int, pred_prob: float,
               actual_ret: float, sigma_hat: float = 1.0) -> None:
        self.predicted_signs.append(int(pred_sign))
        self.predicted_probs.append(float(pred_prob))
        self.actual_returns.append(float(actual_ret))
        self.actual_signs.append(int(np.sign(actual_ret)) if actual_ret != 0 else 1)
        level = (2.0 * float(pred_prob) - 1.0) * float(sigma_hat)
        self.forecast_levels.append(level)
        self.errors.append(float(actual_ret - level))

    def add_diagnostics(self, diag: Dict[str, Dict[str, float]]) -> None:
        self.diagnostics.append(diag)

    @property
    def n(self) -> int:
        return len(self.actual_returns)

    @property
    def mse(self) -> float:
        e = np.asarray(self.errors)
        return float(np.mean(e ** 2)) if e.size else float("nan")

    @property
    def rmse(self) -> float:
        return float(np.sqrt(self.mse))

    @property
    def mae(self) -> float:
        e = np.asarray(self.errors)
        return float(np.mean(np.abs(e))) if e.size else float("nan")

    def mase(self, naive_mae: float) -> float:
        return self.mae / naive_mae if naive_mae > 0 else float("nan")

    @property
    def hit_rate(self) -> float:
        if self.n == 0:
            return float("nan")
        return float(np.mean([p == a for p, a in
                               zip(self.predicted_signs, self.actual_signs)]))

    @property
    def hit_array(self) -> np.ndarray:
        return np.array([int(p == a) for p, a in
                         zip(self.predicted_signs, self.actual_signs)], dtype=float)

    @property
    def strategy_returns(self) -> np.ndarray:
        return np.array(self.predicted_signs) * np.array(self.actual_returns)

    @property
    def cumulative_pnl(self) -> np.ndarray:
        return np.cumprod(1.0 + np.clip(self.strategy_returns, -0.5, 0.5))

    @property
    def information_ratio(self) -> float:
        sr = self.strategy_returns
        return (float(np.mean(sr) / (np.std(sr, ddof=1) + 1e-10))
                if len(sr) >= 2 else float("nan"))

    def pt_test(self) -> Tuple[float, float]:
        return pesaran_timmermann_test(
            np.array(self.actual_returns),
            np.array(self.predicted_signs, dtype=float),
        )

    def summary(self, naive_mae: float = 1.0) -> dict:
        pt_stat, pt_pv = self.pt_test()
        return {
            "n": self.n,
            "MSE": self.mse,
            "RMSE": self.rmse,
            "MAE": self.mae,
            "MASE": self.mase(naive_mae),
            "HitRate": self.hit_rate,
            "PT_stat": pt_stat,
            "PT_pvalue": pt_pv,
            "IR": self.information_ratio,
            "TotalPnL": (float(self.cumulative_pnl[-1])
                         if self.n > 0 else float("nan")),
            "Fallbacks": self.fallback_count,
        }

    def diagnostic_summary(self) -> Dict[str, Dict[str, float]]:
        if not self.diagnostics:
            return {}
        agg: Dict[str, Dict[str, float]] = {}
        for test_name in self.diagnostics[0]:
            vals = [d[test_name]["stat"] for d in self.diagnostics
                    if np.isfinite(d[test_name]["stat"])]
            pvs = [d[test_name]["pvalue"] for d in self.diagnostics
                   if np.isfinite(d[test_name]["pvalue"])]
            if vals:
                agg[test_name] = {
                    "mean_stat": float(np.mean(vals)),
                    "mean_pvalue": float(np.mean(pvs)),
                    "rej_5pct": float(np.mean(np.array(pvs) < 0.05)),
                    "count": len(vals),
                }
        return agg


@dataclass
class LevelResults:
    """Stores level-domain predictions and actuals for the DGP demo."""
    name: str
    forecasts: List[float] = field(default_factory=list)
    actuals: List[float] = field(default_factory=list)
    errors: List[float] = field(default_factory=list)
    fallback_count: int = 0

    def append(self, f: float, a: float) -> None:
        self.forecasts.append(float(f))
        self.actuals.append(float(a))
        self.errors.append(float(a - f))

    @property
    def n(self) -> int:
        return len(self.errors)

    @property
    def mse(self) -> float:
        return float(np.mean(np.array(self.errors) ** 2)) if self.errors else float("nan")

    @property
    def rmse(self) -> float:
        return float(np.sqrt(self.mse))

    @property
    def mae(self) -> float:
        return float(np.mean(np.abs(self.errors))) if self.errors else float("nan")

    def mase(self, naive_mae: float) -> float:
        return self.mae / naive_mae if naive_mae > 0 else float("nan")

    @property
    def hit_rate(self) -> float:
        if not self.forecasts:
            return float("nan")
        f = np.sign(self.forecasts)
        f[f == 0] = 1
        a = np.sign(self.actuals)
        a[a == 0] = 1
        return float(np.mean(f == a))

    @property
    def hit_indicators(self) -> np.ndarray:
        f = np.sign(np.array(self.forecasts, dtype=float))
        f[f == 0] = 1
        a = np.sign(np.array(self.actuals, dtype=float))
        a[a == 0] = 1
        return (f == a).astype(float)

    def pt_test(self) -> Tuple[float, float]:
        return pesaran_timmermann_test(
            np.array(self.actuals), np.array(self.forecasts))

    def summary(self, naive_mae: float = 1.0) -> dict:
        pt_s, pt_p = self.pt_test()
        return {
            "n": self.n,
            "MSE": self.mse, "RMSE": self.rmse, "MAE": self.mae,
            "MASE": self.mase(naive_mae),
            "HitRate": self.hit_rate,
            "PT_stat": pt_s, "PT_pvalue": pt_p,
            "Fallbacks": self.fallback_count,
        }


# ======================================================================
# MODULE 9 — DATA
# ======================================================================

TICKERS: Dict[str, str] = {
    "SPY": "S&P 500 ETF",
    "QQQ": "Nasdaq-100 ETF",
    "EWZ": "Brazil ETF",
    "GLD": "Gold ETF",
    "AAPL": "Apple",
    "JPM": "JPMorgan",
}


def fetch_yfinance(ticker: str, period: str = "5y") -> Optional[np.ndarray]:
    try:
        import yfinance as yf
        df = yf.Ticker(ticker).history(period=period, auto_adjust=True)
        if df is None or len(df) < 50:
            return None
        return df["Close"].dropna().values.astype(float)
    except Exception:
        return None


def prices_to_returns(prices: np.ndarray, freq: str = "daily") -> np.ndarray:
    logp = np.log(prices)
    if freq == "daily":
        return np.diff(logp)
    if freq == "weekly":
        return np.diff(logp[::5])
    if freq == "monthly":
        return np.diff(logp[::21])
    raise ValueError(f"Unknown frequency {freq!r}")


def synthetic_gjr_garch(n: int = 2000, seed: int = 0) -> np.ndarray:
    """Simulate returns from a GJR-GARCH(1,1) with Student-t innovations."""
    rng = np.random.default_rng(seed)
    omega, alpha, gamma, beta, df = 2e-6, 0.04, 0.06, 0.90, 5.0
    scale = np.sqrt((df - 2) / df)
    h = np.ones(n) * omega / (1 - alpha - 0.5 * gamma - beta)
    r = np.zeros(n)
    for t in range(1, n):
        ind = float(r[t - 1] < 0)
        h[t] = omega + (alpha + gamma * ind) * r[t - 1] ** 2 + beta * h[t - 1]
        r[t] = np.sqrt(h[t]) * rng.standard_t(df) * scale
    return r


def get_return_series(ticker: str, freq: str, use_synthetic: bool,
                      n_override: Optional[int] = None) -> Tuple[np.ndarray, str]:
    if not use_synthetic:
        prices = fetch_yfinance(ticker, period="5y")
        if prices is not None and len(prices) > 100:
            ret = prices_to_returns(prices, freq)
            return ret, f"{TICKERS.get(ticker, ticker)} ({ticker}) -- Yahoo Finance, {freq}"
    n_map = {"daily": 2500, "weekly": 500, "monthly": 120}
    seed_map = {t: i * 7 for i, t in enumerate(TICKERS)}
    n = n_override if n_override is not None else n_map.get(freq, 2500)
    seed = seed_map.get(ticker, 0) + {"daily": 0, "weekly": 3, "monthly": 7}.get(freq, 0)
    r = synthetic_gjr_garch(n=n, seed=seed)
    if freq == "weekly":
        r = np.array([r[i: i + 5].sum() for i in range(0, len(r) - 5, 5)])
    elif freq == "monthly":
        r = np.array([r[i: i + 21].sum() for i in range(0, len(r) - 21, 21)])
    return r, f"{TICKERS.get(ticker, ticker)} ({ticker}) -- Synthetic GJR-GARCH, {freq}"


def dgp_ar1_gaussian(n: int, rho: float = 0.55,
                     sigma: float = 1.0, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    x = np.zeros(n)
    x[0] = rng.normal(0, sigma / np.sqrt(max(1 - rho ** 2, 1e-6)))
    for t in range(1, n):
        x[t] = rho * x[t - 1] + rng.normal(0, sigma)
    return x


def dgp_nonlinear_student(n: int, rho: float = 0.60, df: float = 4.0,
                           g_true: float = 0.5, seed: int = 1) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scale = np.sqrt((df - 2) / df)
    x = np.zeros(n)
    for t in range(1, n):
        z = np.sign(x[t - 1]) * abs(x[t - 1]) ** g_true
        x[t] = rho * z + rng.standard_t(df) * scale
    return x


def dgp_threshold_ar(n: int, rho_lo: float = 0.7, rho_hi: float = -0.2,
                     thresh: float = 0.0, seed: int = 2) -> np.ndarray:
    rng = np.random.default_rng(seed)
    x = np.zeros(n)
    for t in range(1, n):
        rho = rho_lo if x[t - 1] <= thresh else rho_hi
        x[t] = rho * x[t - 1] + rng.normal(0, 1.0)
    return x


# ======================================================================
# MODULE 10 — BACKTEST ENGINES
# ======================================================================

def _get_naive_mae(results: Dict[str, SignResults]) -> float:
    for res in results.values():
        nm = getattr(res, "_naive_mae", None)
        if nm is not None:
            return float(nm)
    return 1.0


def run_sign_backtest(
    returns: np.ndarray,
    label: str,
    min_train: int = 120,
    d_max: int = 5,
    n_sim: int = 20_000,
    refit_every: int = 10,
    lam_logistic: float = 1.0,
    verbose: bool = True,
    rng_seed: int = 42,
    fallback_policy: str = "mean",
    compute_diagnostics: bool = True,
) -> Dict[str, SignResults]:
    """
    Rolling walk-forward sign backtest covering all three SPGF objectives.

    Forecasters
    -----------
    BuyHold       — passive long-only benchmark
    AR1-Sign      — sign(a + b·x_t), OLS fitted
    SPGF-MSE      — SPGFForecaster(loss="MSE"): predict_sign wraps the
                    level forecast a* + b*·sgn(x)|x|^g* optimised under
                    squared error.  Implements paper Theorem 3.1.
    SPGF-MAE      — SPGFForecaster(loss="MAE"): predict_sign wraps the
                    median-regression level forecast optimised under
                    absolute error.  Implements paper Theorem 3.2.
    SPGF-Sign     — SPGFSignForecaster: tau* from copula simulation,
                    light-weight and sign-only.  Implements paper §5–6.
    SPGF-Full     — SPGFForecaster(loss="SIGN"): full estimator, SIGN
                    loss, g inherited from MSE.  Equivalent to SPGF-Sign
                    but estimated through the unified SPGFEstimator path
                    so all three loss values are computed simultaneously.
    MultiLag-Log  — logistic regression on lagged signs
    CopulaProb    — P(r_{t+1}>0 | r_t) from copula  (paper §7.5)
    Ensemble      — majority vote of AR1-Sign, SPGF-Sign, MultiLag-Log,
                    CopulaProb  (paper Proposition 8.1)

    Design notes
    ------------
    •  SPGF-MSE and SPGF-MAE use predict_sign / predict_prob from the
       SPGFForecaster, which squash the level forecast through a logistic
       for probability output.  The sign decision is exact (sign of the
       level), the probability is a monotone proxy.
    •  SPGF-Full uses the same SPGFEstimator path as SPGF-MSE/MAE so
       the three loss criteria share a single Monte-Carlo simulation
       per refit, keeping runtime controlled.
    •  Fallback is per-forecaster: a failure in one forecaster does not
       drop the observation for other forecasters.
    """
    T = len(returns)
    if min_train <= d_max:
        min_train = d_max + 1
    n_eval = T - min_train
    if n_eval < 10:
        print(f" WARNING: too few evaluation points ({n_eval}), skipping.")
        return {}

    names = [
        "BuyHold", "AR1-Sign",
        "SPGF-MSE", "SPGF-MAE", "SPGF-Sign", "SPGF-Full",
        "MultiLag-Log", "CopulaProb", "Ensemble",
    ]
    results = {name: SignResults(name=name) for name in names}

    # ---- Instantiate forecasters ----
    buyhold   = BuyAndHoldForecaster()
    ar1       = AR1SignForecaster()
    # Lightweight sign-only path (original SPGFSignForecaster)
    spgf_sign = SPGFSignForecaster(d_max=min(d_max, 3), n_sim=n_sim)
    # Full SPGFForecaster for all three loss criteria
    spgf_d    = min(d_max, 3)
    spgf_mse  = SPGFForecaster(loss="MSE",  d_max=spgf_d, n_sim=n_sim)
    spgf_mae  = SPGFForecaster(loss="MAE",  d_max=spgf_d, n_sim=n_sim)
    spgf_full = SPGFForecaster(loss="SIGN", d_max=spgf_d, n_sim=n_sim)
    mll       = MultiLagLogisticForecaster(d_max=d_max, lam=lam_logistic)
    cp        = CopulaProbForecaster()
    ens       = EnsembleSignForecaster(ar1, spgf_sign, mll, cp)

    naive_mae = float(np.mean(np.abs(np.diff(returns[:min_train]))))
    if naive_mae <= 1e-12:
        naive_mae = 1.0

    if verbose:
        print("\n" + "=" * 70)
        print(f" {label}")
        print(f" T={T}  min_train={min_train}  eval={n_eval}  "
              f"d_max={d_max}  refit_every={refit_every}")
        print("=" * 70)

    fitted_once = False
    for step, t in enumerate(range(min_train, T)):
        x_train   = returns[:t]
        x_context = returns[max(0, t - d_max - 1): t]
        actual    = float(returns[t])
        rng       = np.random.default_rng([rng_seed, step])
        sigma_hat = float(np.std(x_train, ddof=1)) if len(x_train) > 1 else 1.0
        do_expensive = (step % refit_every == 0) or (not fitted_once)

        # ---- Fit ----
        try:
            if do_expensive:
                buyhold.fit(x_train)
                ar1.fit(x_train)
                # Three SPGFForecasters share one copula/simulation budget each.
                # We fit them independently so each can store its own params_.
                spgf_sign.fit(x_train, rng=np.random.default_rng([rng_seed, step, 0]))
                spgf_mse .fit(x_train, rng=np.random.default_rng([rng_seed, step, 1]))
                spgf_mae .fit(x_train, rng=np.random.default_rng([rng_seed, step, 2]))
                spgf_full.fit(x_train, rng=np.random.default_rng([rng_seed, step, 3]))
                cp.fit(x_train)
                fitted_once = True
            mll.fit(x_train)
        except Exception as e:
            if verbose:
                print(f" fit error at step {step}: {e!r}")

        # ---- Diagnostics (on SPGF-Sign results carrier) ----
        if compute_diagnostics and do_expensive and len(x_train) > min_train:
            try:
                diag = run_diagnostic_tests(
                    x_train, results["SPGF-Sign"], d_max=min(d_max, 3))
                results["SPGF-Sign"].add_diagnostics(diag)
            except Exception:
                pass

        # ---- Per-forecaster prediction with individual fallback ----
        forecast_specs = [
            ("BuyHold",      buyhold,    False),
            ("AR1-Sign",     ar1,        True),   # True = scalar interface
            ("SPGF-MSE",     spgf_mse,   False),
            ("SPGF-MAE",     spgf_mae,   False),
            ("SPGF-Sign",    spgf_sign,  False),
            ("SPGF-Full",    spgf_full,  False),
            ("MultiLag-Log", mll,        False),
            ("CopulaProb",   cp,         False),
            ("Ensemble",     ens,        False),
        ]
        for name, forecaster, scalar_iface in forecast_specs:
            try:
                arg = float(x_context[-1]) if scalar_iface else x_context
                s = int(forecaster.predict_sign(arg))
                p = float(forecaster.predict_prob(arg))
                if not np.isfinite(s) or not np.isfinite(p):
                    raise ValueError("non-finite prediction")
                results[name].append(s, p, actual, sigma_hat)
            except Exception as e:
                results[name].fallback_count += 1
                if len(results[name].failure_messages) < 5:
                    results[name].failure_messages.append(repr(e))
                if fallback_policy == "mean":
                    s = 1 if np.mean(returns[:t]) > 0 else -1
                    p = 0.5 + 0.25 * s
                else:
                    s, p = 1, 0.75
                results[name].append(s, p, actual, sigma_hat)

        if verbose and (step % max(1, n_eval // 8) == 0 or step == n_eval - 1):
            pct = 100 * (step + 1) / n_eval
            print(f" step {step + 1:>4}/{n_eval} ({pct:>3.0f}%)", flush=True)

    for res in results.values():
        res._naive_mae = naive_mae  # type: ignore[attr-defined]
    return results


def run_level_backtest(
    x: np.ndarray,
    min_train: int,
    forecasters: Dict[str, object],
    refit_every: Dict[str, int],
    fallback_policy: str = "mean",
) -> Dict[str, LevelResults]:
    """
    Rolling level-domain backtest for any mix of level-domain forecasters.

    Each forecaster must implement:
        .fit(x_train: np.ndarray) -> self
        .predict(x_context: np.ndarray) -> float

    SPGFForecaster satisfies both interfaces, so SPGF-MSE / SPGF-MAE /
    SPGF-SIGN can all be included here alongside ThetaForecaster and AR1Forecaster.
    """
    T = len(x)
    results = {name: LevelResults(name=name) for name in forecasters}
    naive_mae = float(np.mean(np.abs(np.diff(x[:min_train]))))
    for step, t in enumerate(range(min_train, T)):
        x_train = x[:t]
        actual  = float(x[t])
        for name, fcast in forecasters.items():
            try:
                if step % refit_every.get(name, 1) == 0:
                    fcast.fit(x_train)  # type: ignore[union-attr]
                f = float(fcast.predict(x_train))  # type: ignore[union-attr]
                if not np.isfinite(f):
                    raise ValueError("non-finite")
            except Exception:
                results[name].fallback_count += 1
                f = float(np.mean(x_train)) if fallback_policy == "mean" else 0.0
            results[name].append(f, actual)
    for res in results.values():
        res._naive_mae = naive_mae  # type: ignore[attr-defined]
    return results


def run_unified_backtest(
    x: np.ndarray,
    label: str,
    min_train: int = 120,
    d_max: int = 4,
    n_sim: int = 20_000,
    refit_every: int = 10,
    copula_family: str = "auto",
    fallback_policy: str = "mean",
    verbose: bool = True,
    rng_seed: int = 42,
) -> Dict[str, LevelResults]:
    """
    General-purpose rolling backtest for arbitrary univariate series.

    Implements ALL THREE paper objectives on a level-domain basis:

        SPGF-MSE   — optimal under squared error loss   (Theorem 3.1)
        SPGF-MAE   — optimal under absolute error loss  (Theorem 3.2)
        SPGF-Sign  — optimal under directional accuracy (Theorem 5.5)

    Alongside classical benchmarks:
        Theta      — Theta method (Assimakopoulos & Nikolopoulos 2000)
        AR(1)      — Demeaned AR(1) level forecast
        BuyHold    — always predict zero-drift (naive)

    This function is the correct entry point for any series that is NOT a
    financial return series, including macro time series, climate data,
    energy prices, or any other domain where level forecasts are meaningful
    and the practitioner wants to compare all three SPGF loss criteria.

    The sign-domain metrics (HitRate, PT-test, Information Ratio) are also
    computed from the level forecasts by thresholding at zero, making
    LevelResults directly comparable to SignResults for the directional
    performance statistics.

    Parameters
    ----------
    x            : univariate time series (raw levels or returns)
    label        : display label for reporting
    min_train    : minimum in-sample window before first out-of-sample step
    d_max        : maximum lag depth for SPGF estimator
    n_sim        : Monte Carlo chain length for SPGFEstimator
    refit_every  : how often to refit the expensive SPGF models (steps)
    copula_family: "auto" or any specific family name
    fallback_policy: "mean" or "zero"
    verbose      : print progress
    rng_seed     : base random seed
    """
    T = len(x)
    n_eval = T - min_train
    if n_eval < 10:
        print(f" WARNING: too few evaluation points ({n_eval}), skipping.")
        return {}

    spgf_kw = dict(copula_family=copula_family, d_max=min(d_max, 3), n_sim=n_sim)
    forecasters: Dict[str, object] = {
        "SPGF-MSE":  SPGFForecaster(loss="MSE",  **spgf_kw),
        "SPGF-MAE":  SPGFForecaster(loss="MAE",  **spgf_kw),
        "SPGF-Sign": SPGFForecaster(loss="SIGN", **spgf_kw),
        "Theta":     ThetaForecaster(),
        "AR(1)":     AR1Forecaster(),
        "BuyHold":   AR1Forecaster(),   # zero-drift proxy
    }
    refit_schedule = {
        k: refit_every if k.startswith("SPGF") else 1
        for k in forecasters
    }

    if verbose:
        print("\n" + "=" * 70)
        print(f" UNIFIED BACKTEST — {label}")
        print(f" T={T}  min_train={min_train}  eval={n_eval}  "
              f"d_max={min(d_max,3)}  refit_every={refit_every}")
        print("=" * 70)

    results = run_level_backtest(x, min_train, forecasters,
                                 refit_schedule, fallback_policy)

    if verbose:
        nm = getattr(list(results.values())[0], "_naive_mae", 1.0)
        rows = sorted(results.items(), key=lambda kv: kv[1].summary(nm)["RMSE"])
        print(f"\n{'Forecaster':<16} {'RMSE':>9} {'MAE':>9} {'MASE':>7} "
              f"{'HitRate':>9} {'PT-p':>9} {'FB':>5}")
        print("-" * 68)
        for name, lr in rows:
            s = lr.summary(nm)
            print(f"{name:<16} {s['RMSE']:>9.5f} {s['MAE']:>9.5f} {s['MASE']:>7.4f} "
                  f"{s['HitRate']:>9.4f} {s['PT_pvalue']:>9.4f} {s['Fallbacks']:>5}")
        # DM tables
        names = list(results.keys())
        for loss in ("MSE", "MAE"):
            print(f"\n DM ({loss})")
            print(" " * 16 + " ".join(f"{n[:8]:>8}" for n in names))
            for n1 in names:
                row = f" {n1:<16}"
                for n2 in names:
                    if n1 == n2:
                        row += f" {'---':>8}"
                    else:
                        dm, pv = diebold_mariano_test(
                            np.array(results[n1].errors),
                            np.array(results[n2].errors), loss=loss)
                        row += f" {('+' if dm > 0 else '-')}{pv:.4f}"
                print(row)
        print("\n DM (SIGN)")
        print(" " * 16 + " ".join(f"{n[:8]:>8}" for n in names))
        for n1 in names:
            row = f" {n1:<16}"
            for n2 in names:
                if n1 == n2:
                    row += f" {'---':>8}"
                else:
                    dm, pv = diebold_mariano_sign(
                        results[n1].hit_indicators, results[n2].hit_indicators)
                    row += f" {('+' if dm > 0 else '-')}{pv:.4f}"
            print(row)

    return results


# ======================================================================
# MODULE 11 — REPORTING
# ======================================================================

def print_statistical_leaderboard(results: Dict[str, SignResults],
                                  label: str = "") -> None:
    if not results:
        return
    nm = _get_naive_mae(results)
    rows = sorted(results.items(), key=lambda kv: kv[1].summary(nm)["RMSE"])
    sep = "-" * 86
    print(sep)
    print(f" Statistical metrics — {label}" if label else " Statistical metrics")
    print(sep)
    print(f" {'Forecaster':<16} {'N':>5} {'MSE':>12} {'RMSE':>10} "
          f"{'MAE':>10} {'MASE':>8} {'HitRate':>9}")
    print(sep)
    for name, res in rows:
        s = res.summary(nm)
        mase_str = f"{s['MASE']:>8.4f}" if np.isfinite(s["MASE"]) else f"{'N/A':>8}"
        print(f" {name:<16} {s['n']:>5} {s['MSE']:>12.6f} {s['RMSE']:>10.6f} "
              f"{s['MAE']:>10.6f} {mase_str} {s['HitRate']:>9.4f}")
    print(sep)


def print_economic_leaderboard(results: Dict[str, SignResults],
                               label: str = "") -> None:
    if not results:
        return
    nm = _get_naive_mae(results)
    rows = sorted(results.items(), key=lambda kv: -kv[1].hit_rate)
    sep = "-" * 86
    print(sep)
    print(f" Economic metrics — {label}" if label else " Economic metrics")
    print(sep)
    print(f" {'Forecaster':<16} {'N':>5} {'HitRate':>9} {'PT-stat':>9} "
          f"{'PT-p':>9} {'IR':>9} {'PnLx':>9} {'FB':>5}")
    print(sep)
    for name, res in rows:
        s = res.summary(nm)
        star = "**" if s["PT_pvalue"] < 0.01 else "*" if s["PT_pvalue"] < 0.05 else ""
        print(f" {name:<16} {s['n']:>5} {s['HitRate']:>9.4f} {s['PT_stat']:>9.3f} "
              f"{s['PT_pvalue']:>8.4f}{star:<2} {s['IR']:>9.4f} "
              f"{s['TotalPnL']:>8.3f}x {s['Fallbacks']:>5}")
    print(sep)


def print_dm_statistical_table(results: Dict[str, SignResults],
                               loss: str = "MSE") -> None:
    if not results:
        return
    names = list(results.keys())
    errors = {n: np.array(results[n].errors) for n in names}
    print(f"\n DM test ({loss.upper()} loss, HLN-corrected)")
    print(" " * 16 + " ".join(f"{n[:10]:>10}" for n in names))
    for n1 in names:
        row = f" {n1:<16}"
        for n2 in names:
            if n1 == n2:
                row += f" {'---':>10}"
            else:
                dm, pv = diebold_mariano_test(errors[n1], errors[n2], loss=loss.upper())
                sig = "**" if pv < 0.01 else "*" if pv < 0.05 else ""
                row += f" {('+' if dm > 0 else '-') + f'{pv:.4f}' + sig:>10}"
        print(row)
    print()


def print_dm_sign_table(results: Dict[str, SignResults]) -> None:
    if not results:
        return
    names = list(results.keys())
    hits = {n: results[n].hit_array for n in names}
    print("\n DM test (SIGN loss, HAC / normal, no HLN correction)")
    print(" " * 16 + " ".join(f"{n[:10]:>10}" for n in names))
    for n1 in names:
        row = f" {n1:<16}"
        for n2 in names:
            if n1 == n2:
                row += f" {'---':>10}"
            else:
                dm, pv = diebold_mariano_sign(hits[n1], hits[n2])
                sig = "**" if pv < 0.01 else "*" if pv < 0.05 else ""
                row += f" {('+' if dm > 0 else '-') + f'{pv:.4f}' + sig:>10}"
        print(row)
    print()


def print_diagnostic_table(results: Dict[str, SignResults]) -> None:
    for name, res in results.items():
        if not res.diagnostics:
            continue
        ds = res.diagnostic_summary()
        if not ds:
            continue
        print("\n" + "=" * 64)
        print(f" DIAGNOSTIC TESTS (rolling-window averages) — {name}")
        print("=" * 64)
        print(f"{'Test':<16} {'Mean Stat':>12} {'Mean p-val':>12} "
              f"{'Rej@5%':>10} {'Count':>8}")
        print("-" * 64)
        for tname, s in ds.items():
            print(f"{tname:<16} {s['mean_stat']:>12.4f} {s['mean_pvalue']:>12.4f} "
                  f"{s['rej_5pct']:>10.3f} {s['count']:>8}")
        print("=" * 64)
        return  # print once (SPGF-Sign is the primary carrier)


def print_full_leaderboard(results: Dict[str, SignResults], label: str = "") -> None:
    print_statistical_leaderboard(results, label=label)
    print_economic_leaderboard(results, label=label)
    print_dm_statistical_table(results, loss="MSE")
    print_dm_statistical_table(results, loss="MAE")
    print_dm_sign_table(results)
    print_diagnostic_table(results)


# Backwards-compatible alias
def print_sign_leaderboard(results: Dict[str, SignResults], label: str = "") -> None:
    print_full_leaderboard(results, label=label)


def _cross_asset_table(all_results, methods, freqs, metric_fn, title):
    print("\n" + "=" * 76)
    print(f" {title}")
    print("=" * 76)
    for freq in freqs:
        print(f"\n Horizon: {freq.upper()}")
        print(f" {'Asset':<10}" + "".join(f" {m[:12]:>12}" for m in methods))
        print(" " + "-" * 74)
        for ticker, freq_dict in all_results.items():
            if freq not in freq_dict or not freq_dict[freq]:
                continue
            res = freq_dict[freq]
            row = f" {ticker:<10}"
            for m in methods:
                row += metric_fn(res, m) if m in res else f" {'N/A':>12}"
            print(row)


_ALL_METHODS = [
    "BuyHold", "AR1-Sign",
    "SPGF-MSE", "SPGF-MAE", "SPGF-Sign", "SPGF-Full",
    "MultiLag-Log", "CopulaProb", "Ensemble",
]
_ALL_FREQS = ["daily", "weekly", "monthly"]


def print_cross_asset_summary(all_results) -> None:
    def fn(res, m):
        hr  = res[m].hit_rate
        sig = "†" if res[m].pt_test()[1] < 0.10 else " "
        return f" {hr:>11.4f}{sig}"
    _cross_asset_table(all_results, _ALL_METHODS, _ALL_FREQS, fn,
                       "CROSS-ASSET DIRECTIONAL ACCURACY (HitRate, † PT-test p<0.10)")


def print_cross_asset_rmse(all_results) -> None:
    _cross_asset_table(all_results, _ALL_METHODS, _ALL_FREQS,
                       lambda res, m: f" {res[m].rmse:>12.5f}",
                       "CROSS-ASSET RMSE (level-scaled forecast errors)")


def print_cross_asset_mase(all_results) -> None:
    _cross_asset_table(all_results, _ALL_METHODS, _ALL_FREQS,
                       lambda res, m: f" {res[m].mase(_get_naive_mae(res)):>12.5f}",
                       "CROSS-ASSET MASE (naive-scaled absolute forecast errors)")


def print_cross_asset_ir(all_results) -> None:
    _cross_asset_table(all_results, _ALL_METHODS, _ALL_FREQS,
                       lambda res, m: f" {res[m].information_ratio:>12.4f}",
                       "CROSS-ASSET INFORMATION RATIO (long-short sign strategy)")


def print_pnl_summary(all_results) -> None:
    _cross_asset_table(
        all_results, _ALL_METHODS, _ALL_FREQS,
        lambda res, m: f" {res[m].summary(_get_naive_mae(res))['TotalPnL']:>11.3f}x",
        "LONG-SHORT CUMULATIVE P&L (gross, 1x leverage, no transaction costs)",
    )


# ======================================================================
# MODULE 12 — DGP DEMO (controlled laboratory evaluation)
# ======================================================================

def run_dgp_demo(fast: bool = False, fallback_policy: str = "mean") -> None:
    """
    Evaluates all three SPGF objectives (MSE, MAE, SIGN) plus classical
    benchmarks on three synthetic DGPs under controlled laboratory conditions.

    Uses run_unified_backtest() — the correct entry point for non-financial
    or general-purpose series — so all paper results are covered:

        Theorem 3.1  → SPGF-MSE
        Theorem 3.2  → SPGF-MAE
        Theorem 5.5  → SPGF-Sign  (directional accuracy = 0.5 + 0.5·kappa)

    DGPs
    ----
    1. Gaussian AR(1)          — ideal case for linear predictors
    2. Nonlinear Markov (g=0.5) — designed so SPGF-MSE outperforms AR(1)
    3. Threshold AR(1)         — sign-monotonicity may fail; tests robustness
    """
    T         = 250 if fast else 600
    min_train = 80  if fast else 150
    n_sim     = 2_000 if fast else 20_000
    d_max     = 1 if fast else 4
    refit     = 10

    print("\n" + "=" * 70)
    print(" SPGF DEMO — All Three Loss Criteria on Controlled DGPs")
    print(" CAIL-WP-2026-SPGF-01")
    print("=" * 70)
    if fast:
        print(" [FAST MODE]")

    dgps = {
        "Gaussian AR(1)  [rho=0.55]":
            dgp_ar1_gaussian(T, rho=0.55, seed=10),
        "Nonlinear Markov [Student-t, g_true=0.5]":
            dgp_nonlinear_student(T, rho=0.65, df=4.0, g_true=0.5, seed=20),
        "Threshold AR(1)  [rho_lo=0.75, rho_hi=-0.25]":
            dgp_threshold_ar(T, rho_lo=0.75, rho_hi=-0.25, seed=30),
    }

    all_res: Dict[str, Dict[str, LevelResults]] = {}
    for label, x in dgps.items():
        res = run_unified_backtest(
            x, label,
            min_train=min_train, d_max=d_max, n_sim=n_sim,
            refit_every=refit, fallback_policy=fallback_policy, verbose=True,
        )
        all_res[label] = res

    # Cross-DGP HitRate summary
    print("\n" + "=" * 72)
    print("CROSS-DGP SUMMARY (HitRate)")
    names = ["SPGF-MSE", "SPGF-MAE", "SPGF-Sign", "Theta", "AR(1)", "BuyHold"]
    print(f"{'DGP':<46}" + "".join(f" {n:>10}" for n in names))
    for label, r in all_res.items():
        row = f"{label:<46}"
        for n in names:
            hr = r[n].hit_rate if n in r else float("nan")
            row += f" {hr:>10.4f}"
        print(row)

    print("\n" + "=" * 72)
    print("CROSS-DGP SUMMARY (RMSE)")
    print(f"{'DGP':<46}" + "".join(f" {n:>10}" for n in names))
    for label, r in all_res.items():
        nm  = getattr(list(r.values())[0], "_naive_mae", 1.0)
        row = f"{label:<46}"
        for n in names:
            rmse = r[n].rmse if n in r else float("nan")
            row += f" {rmse:>10.5f}"
        print(row)


# ======================================================================
# MODULE 13 — MAIN
# ======================================================================

def main() -> None:
    use_synthetic = "--synthetic" in sys.argv
    fast = "--fast" in sys.argv
    demo = "--demo" in sys.argv
    no_diagnostics = "--no-diagnostics" in sys.argv
    fallback_policy = "mean"
    for arg in sys.argv:
        if arg.startswith("--fallback="):
            fallback_policy = arg.split("=", 1)[1].strip().lower()

    if demo:
        run_dgp_demo(fast=fast, fallback_policy=fallback_policy)
        return

    # ---- Financial backtest ----
    if fast:
        ASSETS = ["SPY", "GLD"]
        FREQS = ["daily", "weekly"]
        MIN_TRAIN = {"daily": 60, "weekly": 30, "monthly": 24}
        D_MAX = 2
        N_SIM = 1_500
        REFIT_EVERY = 10
        N_SYNTH = {"daily": 400, "weekly": 800, "monthly": 80}
    else:
        ASSETS = list(TICKERS.keys())
        FREQS = ["daily", "weekly", "monthly"]
        MIN_TRAIN = {"daily": 120, "weekly": 60, "monthly": 36}
        D_MAX = 5
        N_SIM = 20_000
        REFIT_EVERY = 10
        N_SYNTH = {"daily": 2500, "weekly": 500, "monthly": 120}

    print("\n" + "=" * 64)
    print(" SPGF FINANCIAL RETURNS — MASTER UNIFIED EXPERIMENT")
    print(" CAIL-WP-2026-SPGF-01")
    print("=" * 64)
    for tag, cond in [("FAST MODE", fast), ("SYNTHETIC DATA", use_synthetic),
                      ("DIAGNOSTICS OFF", no_diagnostics)]:
        if cond:
            print(f" [{tag}]")
    print(f" Assets   : {', '.join(ASSETS)}")
    print(f" Horizons : {', '.join(FREQS)}")
    print(f" d_max={D_MAX}  n_sim={N_SIM}  refit_every={REFIT_EVERY}")

    all_results: Dict[str, Dict[str, Dict[str, SignResults]]] = {}
    t0 = time.perf_counter()

    for ticker in ASSETS:
        all_results[ticker] = {}
        for freq in FREQS:
            returns, series_label = get_return_series(
                ticker, freq, use_synthetic, n_override=N_SYNTH.get(freq))
            if len(returns) < MIN_TRAIN[freq] + 20:
                print(f" Skipping {ticker}/{freq}: too few observations ({len(returns)})")
                continue
            res = run_sign_backtest(
                returns=returns,
                label=series_label,
                min_train=MIN_TRAIN[freq],
                d_max=D_MAX,
                n_sim=N_SIM,
                refit_every=REFIT_EVERY,
                lam_logistic=1.0,
                verbose=True,
                rng_seed=42,
                fallback_policy=fallback_policy,
                compute_diagnostics=not no_diagnostics,
            )
            all_results[ticker][freq] = res
            print_full_leaderboard(res, label=series_label)

    print_cross_asset_summary(all_results)
    print_cross_asset_rmse(all_results)
    print_cross_asset_mase(all_results)
    print_cross_asset_ir(all_results)
    print_pnl_summary(all_results)

    elapsed = time.perf_counter() - t0
    print(f"\n Total wall time: {elapsed:.1f}s")
    print("\n Done.  Results above are ready for inclusion in")
    print(" CAIL-WP-2026-SPGF-01, Section 8 (Financial Returns).")


if __name__ == "__main__":
    main()
