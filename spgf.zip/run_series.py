#!/usr/bin/env python3
"""run_series.py -- Generic entry point for ANY univariate time series.

Purpose-built for the case raised explicitly: applying SPGF to non-financial
series where the user wants to choose (or compare) among MSE, MAE, and SIGN
loss functions, without being forced through the financial PnL/IR framing.

Usage:
    python3 run_series.py --csv path/to/data.csv [--column NAME]
                           [--loss mse|mae|sign|all] [--min-train N] [--dmax N]
                           [--nsim N] [--rolling] [--no-diagnostics]

If --csv is omitted, falls back to a synthetic nonlinear Markov series so the
script is runnable standalone for smoke-testing.
"""
from __future__ import annotations
import sys
import argparse
import numpy as np

from spgf.data import load_series_from_csv, dgp_nonlinear_student
from spgf.forecasters import SPGFForecaster, ThetaForecaster, AR1Forecaster, BuyAndHoldForecaster
from spgf.backtest import RollingBacktester
from spgf.reporting import print_full_leaderboard


def parse_args(argv):
    p = argparse.ArgumentParser(description="Run SPGF on an arbitrary univariate series.")
    p.add_argument("--csv", type=str, default=None, help="Path to CSV file with the series.")
    p.add_argument("--column", type=str, default=None, help="Column name to use (default: last numeric column).")
    p.add_argument("--loss", type=str, default="all", choices=["mse", "mae", "sign", "all"],
                   help="Which SPGF loss(es) to fit and compare. Default: all.")
    p.add_argument("--min-train", type=int, default=None, help="Minimum training window size.")
    p.add_argument("--dmax", type=int, default=4, help="Maximum lag depth to search.")
    p.add_argument("--nsim", type=int, default=20000, help="Simulation length for the SPGF grid search.")
    p.add_argument("--rolling", action="store_true", help="Use rolling (vs expanding) window.")
    p.add_argument("--no-diagnostics", action="store_true", help="Disable Appendix-A diagnostic tests.")
    p.add_argument("--fast", action="store_true", help="Fast smoke-test settings (small N, small nsim).")
    p.add_argument("--fallback", type=str, default="mean", choices=["mean", "zero", "raise"])
    p.add_argument("--baselines", action="store_true", help="Also fit Theta/AR1/BuyHold baselines for comparison.")
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(sys.argv[1:] if argv is None else argv)

    if args.csv is not None:
        x = load_series_from_csv(args.csv, column=args.column)
        series_label = f"CSV series: {args.csv}" + (f" (col={args.column})" if args.column else "")
    else:
        n = 250 if args.fast else 600
        x = dgp_nonlinear_student(n, rho=0.65, df=4.0, gtrue=0.5, seed=20)
        series_label = "Synthetic nonlinear Markov series (no --csv given)"

    fast = args.fast
    dmax = 1 if fast else args.dmax
    nsim = 2000 if fast else args.nsim
    ggrid = np.array([0.5, 1.0, 2.0]) if fast else None
    min_train = args.min_train or max(int(0.3 * len(x)), 30)
    diag_nsim = 1000 if fast else 5000
    window_type = "rolling" if args.rolling else "expanding"
    run_diag = not args.no_diagnostics

    print("=" * 68)
    print("SPGF GENERIC SERIES RUNNER")
    print("=" * 68)
    print(series_label)
    print(f"N={len(x)}  min_train={min_train}  dmax={dmax}  nsim={nsim}  loss={args.loss}  window={window_type}")

    spgf_kw = dict(copula_family="auto", nsim=nsim, dmax=dmax, ggrid=ggrid)
    bt = RollingBacktester(x, min_train=min_train, window_type=window_type, rng_seed=42,
                            verbose=True, fallback_policy=args.fallback, label=series_label)

    losses = ["MSE", "MAE", "SIGN"] if args.loss == "all" else [args.loss.upper()]
    for loss in losses:
        run_diag_here = (loss == "SIGN")
        bt.add_forecaster(f"SPGF-{loss}", SPGFForecaster(loss=loss, **spgf_kw),
                           refit_every=10, run_diagnostics_here=run_diag_here and run_diag)

    if args.baselines:
        bt.add_forecaster("Theta", ThetaForecaster(), refit_every=1)
        bt.add_forecaster("AR1", AR1Forecaster(), refit_every=1)
        bt.add_forecaster("BuyHold", BuyAndHoldForecaster(), refit_every=1)

    bt.run(diagnostics=run_diag, diag_dmax=min(dmax + 1, 5), diag_nsim=diag_nsim)
    print_full_leaderboard(bt.results, label=series_label)


if __name__ == "__main__":
    main()
