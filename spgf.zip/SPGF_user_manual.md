# SPGF Framework — User Manual
### How to change dates, tickers, and parameters to run your own experiments

This manual covers the three entry-point scripts built on top of the `spgf` package:

- `run_demo.py`      — controlled synthetic DGPs (sanity-check environment)
- `run_financial.py` — real/synthetic financial returns, sign-based P&L backtest
- `run_series.py`    — generic entry point for ANY univariate time series (your own CSV), comparing MSE/MAE/SIGN losses

All three share the same underlying engine (`spgf/copulas.py`, `spgf/estimator.py`,
`spgf/forecasters.py`, `spgf/backtest.py`, `spgf/reporting.py`, `spgf/data.py`,
`spgf/diagnostics.py`, `spgf/stats_tests.py`), so parameters you learn to tune in one
script transfer directly to the others.

---

## 1. Quick-start commands

```
python run_demo.py --fast --no-diagnostics
python run_series.py --csv myfile.csv --column price --loss all
python run_financial.py --synthetic --fast
```

Flags common to all three scripts:

| Flag | Effect |
|---|---|
| `--fast` | Shrinks sample size, simulation count, and lag depth for a quick smoke test |
| `--rolling` | Uses a fixed-length rolling training window instead of the default expanding window |
| `--no-diagnostics` | Skips the Appendix-A diagnostic test suite (DNO decay, hit-rate bound, MSE/MAE slope, monotonicity) to save time |
| `--fallback=mean\|zero\|raise` | What happens if a forecaster throws an error mid-backtest: fall back to the training mean, fall back to zero, or raise and stop |

---

## 2. Changing the "dates" (i.e., the sample window and horizon)

There are no literal calendar-date parameters — the scripts pull a rolling window of
recent history via `yfinance` (`period="5y"` by default) or generate synthetic history.
"Date" control instead happens through three levers:

### a. `period` in `spgf/data.py::fetch_yfinance`
```python
def fetch_yfinance(ticker, period="5y"):
```
Change `"5y"` to `"1y"`, `"2y"`, `"10y"`, or `"max"` to pull a longer or shorter
real-data history from Yahoo Finance. This is the closest equivalent to picking a
"start date" — Yahoo Finance periods are relative to today, not absolute dates.

### b. `freq` (sampling horizon)
In `run_financial.py`:
```python
FREQS = ["daily", "weekly", "monthly"]
```
Add/remove any of the three to control how returns are aggregated (daily log-returns,
5-day weekly blocks, or 21-day monthly blocks — see `prices_to_returns` in `spgf/data.py`).

### c. `min_train` (how much history before the first forecast)
This is the real lever for "how many observations before I start scoring":
```python
MIN_TRAIN = {"daily": 120, "weekly": 60, "monthly": 36}   # run_financial.py
min_train = 150                                            # run_demo.py
min_train = args.min_train or max(int(0.3 * len(x)), 30)   # run_series.py (--min-train flag)
```
Raising `min_train` gives the copula/SPGF estimator a more stable initial fit but leaves
fewer out-of-sample points to evaluate; lowering it stress-tests the model in
data-scarce regimes.

If you want a genuinely fixed calendar range, load your own CSV with a date column via
`run_series.py --csv yourfile.csv --column close` and pre-trim the file to the exact
date range you want before passing it in — `load_series_from_csv` in `spgf/data.py`
just reads whatever rows are present, it doesn't filter by date itself.

---

## 3. Changing tickers

Open `spgf/data.py`. All tickers live in one dictionary:
```python
TICKERS = {"SPY": "S&P 500 ETF", "QQQ": "Nasdaq-100 ETF", "EWZ": "Brazil ETF",
           "GLD": "Gold ETF", "AAPL": "Apple", "JPM": "JPMorgan"}
```
To add a new asset (e.g. Microsoft), just add an entry:
```python
TICKERS["MSFT"] = "Microsoft"
```
Then, in `run_financial.py`, either use the full dictionary automatically:
```python
ASSETS = list(TICKERS.keys())
```
or restrict the run to a hand-picked subset:
```python
ASSETS = ["SPY", "MSFT", "GLD"]
```
Any valid Yahoo Finance ticker symbol works even if it's not in `TICKERS` — the label
dictionary is only used for cosmetic naming in the printed reports; unknown tickers
just print their raw symbol instead of a friendly name.

Use `--synthetic` to bypass Yahoo Finance entirely and generate GJR-GARCH synthetic
returns per ticker/frequency instead (useful when you're offline or want a clean,
known data-generating process for testing).

---

## 4. Changing the loss function (MSE / MAE / SIGN)

This is the core "knob" the whole framework is built around. `SPGFForecaster` in
`spgf/forecasters.py` takes a `loss` argument that must be one of `"MSE"`, `"MAE"`,
or `"SIGN"`:

```python
SPGFForecaster(loss="MSE", ...)   # optimizes squared-error accuracy of the level forecast
SPGFForecaster(loss="MAE", ...)   # optimizes absolute-error accuracy (median regression)
SPGFForecaster(loss="SIGN", ...)  # optimizes directional (sign) hit rate
```

- In `run_demo.py` and `run_financial.py`, all three losses are registered
  simultaneously as separate competitors (`SPGF-MSE`, `SPGF-MAE`, `SPGF-SIGN`) so you
  can compare them side by side in the leaderboard.
- In `run_series.py`, use the `--loss` flag directly:
  ```
  python run_series.py --csv data.csv --loss mse
  python run_series.py --csv data.csv --loss mae
  python run_series.py --csv data.csv --loss sign
  python run_series.py --csv data.csv --loss all      # runs and compares all three (default)
  ```

Internally, each loss changes which regression/optimization the `SPGFEstimator` runs
over the simulated copula chain (`spgf/estimator.py`): OLS for MSE, iterative L1/median
regression for MAE, and a grid search over sign-accuracy thresholds `tau` for SIGN.

---

## 5. Changing SPGF estimator parameters

These control how the SPGF functional searches for the best nonlinear predictive rule,
and are passed as constructor arguments to `SPGFForecaster`:

| Parameter | Default | Meaning |
|---|---|---|
| `dmax` | 4 (demo), varies elsewhere | Maximum lag depth `d` considered. Higher = considers longer memory, more compute |
| `nsim` | 20,000–50,000 | Length of the Markov chain simulated from the fitted copula to estimate the loss surface. Higher = smoother, less Monte Carlo noise, slower |
| `ggrid` | `[0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]` | The grid of "sign-power" exponents \(g\) tried in \( \text{sign}(x)\lvert x\rvert^{g} \). Add finer or more extreme values (e.g. `0.1`, `4.0`) to capture different nonlinear risk/return shapes |
| `copula_family` | `"auto"` | Forces a specific dependence structure instead of letting the pseudo-log-likelihood pick automatically. Choices: `"gaussian"`, `"studentt"`, `"clayton"`, `"gumbel"`, `"frank"`, `"empirical"` |
| `studentt_df` | 4.0 | Degrees of freedom for the Student-t copula if selected/forced. Lower = fatter tails, more tail dependence |

Example — force a Clayton copula with a coarser grid and shorter simulation for a quick test:
```python
SPGFForecaster(loss="SIGN", copula_family="clayton", ggrid=[0.5, 1.0, 2.0], nsim=5000, dmax=3)
```

`tau_ngrid` (default 200, set inside `SPGFEstimator`) controls how many quantile
thresholds are tried when optimizing the SIGN loss — raise it for a finer threshold
search at the cost of speed.

---

## 6. Changing backtest mechanics

Controlled by `RollingBacktester` in `spgf/backtest.py`, and exposed as arguments in
each entry script:

| Parameter | Meaning |
|---|---|
| `window_type` | `"expanding"` (default: training set grows every step) or `"rolling"` (fixed-length lookback window, set via `--rolling` flag) |
| `refit_every` | How many backtest steps pass between full model refits. `refit_every=1` refits every step (slow but most accurate); `refit_every=10` (default) simulates realistic periodic model updates |
| `rng_seed` | Random seed for reproducibility of copula simulation draws |
| `fallback_policy` | `"mean"`, `"zero"`, or `"raise"` — what to do if a forecaster errors out mid-run |

Example: force a strict rolling 250-observation window, refitting every single step:
```python
bt = RollingBacktester(x, min_train=250, window_type="rolling", ...)
bt.add_forecaster("SPGF-MSE", SPGFForecaster(loss="MSE"), refit_every=1)
```

---

## 7. Changing the synthetic data-generating processes (DGPs)

`run_demo.py` and `run_series.py` (when no `--csv` is given) use controlled synthetic
processes defined in `spgf/data.py`:

- `dgp_ar1_gaussian(n, rho, sigma, seed)` — simple linear AR(1) with Gaussian noise.
  Raise `rho` toward 1 for stronger autocorrelation/predictability.
- `dgp_nonlinear_student(n, rho, df, gtrue, seed)` — nonlinear Markov process with
  Student-t innovations. `gtrue` sets the "true" sign-power exponent; try an unusual
  fraction like `0.66` and see whether the SPGF estimator's `ggrid` search locks onto
  the nearest match.
- `dgp_threshold_ar(n, rho_lo, rho_hi, thresh, seed)` — regime-switching AR(1) that
  flips its autoregressive coefficient depending on whether the last value is above or
  below `thresh`.
- `synthetic_gjr_garch(n, seed)` — used by `run_financial.py --synthetic`; a GJR-GARCH
  volatility process with asymmetric leverage effect (`gamma`) and Student-t
  innovations (`df=5.0` by default).

To run your own DGP experiment, edit the `dgps = {...}` dictionary near the top of
`run_demo.py`'s `main()` function, or write your own generator function following the
same signature (return a 1-D NumPy array) and import it into `run_series.py`.

---

## 8. Using your own data (`run_series.py`)

This is the generic, non-financial entry point. Point it at any CSV with a numeric
column:
```
python run_series.py --csv sensor_readings.csv --column value --loss all --baselines
```
Key flags:

| Flag | Meaning |
|---|---|
| `--csv PATH` | Path to your CSV file |
| `--column NAME` | Which column to use (defaults to the last column if omitted) |
| `--loss {mse,mae,sign,all}` | Which SPGF loss(es) to run |
| `--min-train N` | Override the default 30%-of-series training window |
| `--dmax N` | Maximum lag depth |
| `--nsim N` | Simulation chain length |
| `--rolling` | Use fixed rolling window instead of expanding |
| `--baselines` | Also run Theta, AR1, and Buy-and-Hold-style level baselines for comparison |
| `--fallback {mean,zero,raise}` | Error-handling policy |

`load_series_from_csv` (in `spgf/data.py`) simply reads numeric rows from the chosen
column and skips anything non-numeric — it has no built-in date filtering, so pre-slice
your CSV to the date range you care about before running.

---

## 9. Reading the output

Every script ends by calling `print_full_leaderboard`, which prints, per series:

- **Statistical metrics table**: MSE, RMSE, MAE, MASE (scaled by naive-forecast MAE), HitRate
- **Economic metrics table**: HitRate, Pesaran-Timmermann directional test stat/p-value,
  Information Ratio, cumulative gross P&L, fallback count
- **Diebold-Mariano tables**: pairwise significance tests under MSE, MAE, and SIGN loss
  between every pair of forecasters (`**` = p<0.01, `*` = p<0.05)
- **Diagnostic table** (unless `--no-diagnostics`): DNO concordance-decay test,
  hit-rate upper-bound test, MSE-vs-MAE slope equality test, sign-monotonicity test

`run_financial.py` additionally prints cross-asset summary tables (HitRate, RMSE, MASE,
Information Ratio, and cumulative P&L) across every ticker/frequency combination once
all assets have been processed.

---

## 10. Suggested experiment recipes

- **Test if SPGF genuinely beats a naive AR(1):** run `run_series.py --csv yourdata.csv
  --baselines --loss all` and compare the MASE/HitRate rows for `SPGF-*` against `AR1`
  and `Theta`.
- **Stress-test small-sample robustness:** lower `min_train` and re-run; watch whether
  `Fallbacks` in the economic table climbs.
- **Check nonlinearity detection:** run `dgp_nonlinear_student` with an unusual `gtrue`
  (e.g. `0.35` or `2.5`) via `run_demo.py`, and inspect whether SPGF's fitted `g` (visible
  by inspecting `forecaster.params.g` in code) converges to the nearest grid point.
- **Tail-dependence sensitivity:** force `copula_family="studentt"` with `studentt_df=2.5`
  vs `studentt_df=10.0` and compare Information Ratios — lower df means fatter tails and
  usually higher (but noisier) directional accuracy in crisis-like synthetic data.
