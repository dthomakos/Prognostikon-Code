#!/usr/bin/env python3
"""run_demo.py -- Demo entry point for the SPGF package (controlled DGPs, all losses)."""
from __future__ import annotations
import sys
import numpy as np

from spgf.data import dgp_ar1_gaussian, dgp_nonlinear_student, dgp_threshold_ar
from spgf.forecasters import SPGFForecaster, ThetaForecaster, AR1Forecaster, BuyAndHoldForecaster
from spgf.backtest import RollingBacktester
from spgf.reporting import print_full_leaderboard


def main():
    fast = "--fast" in sys.argv
    window_type = "rolling" if "--rolling" in sys.argv else "expanding"
    run_diag = "--no-diagnostics" not in sys.argv
    fallback_policy = "mean"
    for arg in sys.argv:
        if arg.startswith("--fallback="):
            fallback_policy = arg.split("=", 1)[1].strip().lower()

    T = 250 if fast else 600
    min_train = 80 if fast else 150
    nsim = 2000 if fast else 20000
    dmax = 1 if fast else 4
    diag_nsim = 1000 if fast else 5000
    refit_every_spgf = 10
    ggrid = np.array([0.5, 1.0, 2.0]) if fast else None

    print("=" * 68)
    print("SPGF DEMO -- Controlled DGPs with Full SPGF Estimator (all 3 losses)")
    print("=" * 68)
    if fast:
        print("FAST MODE")

    dgps = {
        "Gaussian AR1": dgp_ar1_gaussian(T, rho=0.55, seed=10),
        "Nonlinear Markov": dgp_nonlinear_student(T, rho=0.65, df=4.0, gtrue=0.5, seed=20),
        "Threshold AR1": dgp_threshold_ar(T, rho_lo=0.75, rho_hi=-0.25, seed=30),
    }

    spgf_kw = dict(copula_family="auto", nsim=nsim, dmax=dmax, ggrid=ggrid)
    all_results = {}

    for label, x in dgps.items():
        print(f"\n--- {label} ---")
        bt = RollingBacktester(x, min_train=min_train, window_type=window_type,
                                rng_seed=42, verbose=True,
                                fallback_policy=fallback_policy, label=label)
        bt.add_forecaster("SPGF-MSE", SPGFForecaster(loss="MSE", **spgf_kw), refit_every=refit_every_spgf)
        bt.add_forecaster("SPGF-MAE", SPGFForecaster(loss="MAE", **spgf_kw), refit_every=refit_every_spgf)
        bt.add_forecaster("SPGF-SIGN", SPGFForecaster(loss="SIGN", **spgf_kw),
                           refit_every=refit_every_spgf, run_diagnostics_here=True)
        bt.add_forecaster("Theta", ThetaForecaster(), refit_every=1)
        bt.add_forecaster("AR1", AR1Forecaster(), refit_every=1)
        bt.add_forecaster("BuyHold", BuyAndHoldForecaster(), refit_every=1)
        bt.run(diagnostics=run_diag, diag_dmax=min(dmax + 1, 5), diag_nsim=diag_nsim)
        all_results[label] = bt.results
        print_full_leaderboard(bt.results, label=label)

    print("\n" + "=" * 72)
    print("CROSS-DGP SUMMARY (HitRate)")
    print("=" * 72)
    names = list(next(iter(all_results.values())).keys())
    print(f"{'DGP':24}" + "".join(f"{n:>12}" for n in names))
    for label, results in all_results.items():
        row = f"{label:24}"
        for n in names:
            row += f"{results[n].hit_rate:12.4f}"
        print(row)


if __name__ == "__main__":
    main()
