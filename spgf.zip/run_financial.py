#!/usr/bin/env python3
"""run_financial.py -- Financial entry point for the SPGF package.

CORRECTED: now registers SPGF under all three loss functions (MSE, MAE, SIGN)
instead of only SIGN, so the statistical leaderboard (RMSE/MAE/MASE) is
populated for SPGF the same way it already is in run_demo.py.
"""
from __future__ import annotations
import sys
import time

from spgf.data import TICKERS, get_return_series
from spgf.forecasters import (
    BuyAndHoldSignForecaster, AR1SignForecaster, SPGFForecaster,
    MultiLagLogisticForecaster, CopulaProbForecaster, EnsembleSignForecaster,
)
from spgf.backtest import RollingBacktester
from spgf.reporting import (
    print_full_leaderboard, print_cross_asset_summary, print_cross_asset_rmse,
    print_cross_asset_mase, print_cross_asset_ir, print_pnl_summary,
)


def build_backtester(returns, label, min_train, dmax, nsim, refit_every,
                      window_type, fallback_policy, rng_seed=42, verbose=True,
                      sign_only=False):
    bt = RollingBacktester(returns, min_train=min_train, window_type=window_type,
                            rng_seed=rng_seed, verbose=verbose,
                            fallback_policy=fallback_policy, label=label)

    spgf_dmax = min(dmax, 3)
    spgf_mse = SPGFForecaster(loss="MSE", copula_family="auto", dmax=spgf_dmax, nsim=nsim)
    spgf_mae = SPGFForecaster(loss="MAE", copula_family="auto", dmax=spgf_dmax, nsim=nsim)
    spgf_sign = SPGFForecaster(loss="SIGN", copula_family="auto", dmax=spgf_dmax, nsim=nsim)

    bt.add_forecaster("SPGF-MSE", spgf_mse, refit_every=refit_every)
    bt.add_forecaster("SPGF-MAE", spgf_mae, refit_every=refit_every)
    bt.add_forecaster("SPGF-Sign", spgf_sign, refit_every=refit_every, run_diagnostics_here=True)

    if not sign_only:
        ar1 = AR1SignForecaster()
        mll = MultiLagLogisticForecaster(dmax=dmax, lam=1.0)
        cp = CopulaProbForecaster()
        ens = EnsembleSignForecaster(ar1, spgf_sign, mll, cp)

        bt.add_forecaster("BuyHold", BuyAndHoldSignForecaster(), refit_every=1)
        bt.add_forecaster("AR1-Sign", ar1, refit_every=1)
        bt.add_forecaster("MultiLag-Log", mll, refit_every=1)
        bt.add_forecaster("CopulaProb", cp, refit_every=1)
        bt.add_forecaster("Ensemble", ens, refit_every=1)
    return bt


def main():
    use_synthetic = "--synthetic" in sys.argv
    fast = "--fast" in sys.argv
    window_type = "rolling" if "--rolling" in sys.argv else "expanding"
    run_diag = "--no-diagnostics" not in sys.argv
    sign_only = "--sign-only" in sys.argv
    fallback_policy = "mean"
    for arg in sys.argv:
        if arg.startswith("--fallback="):
            fallback_policy = arg.split("=", 1)[1].strip().lower()

    if fast:
        ASSETS = ["SPY", "GLD"]
        FREQS = ["daily", "weekly"]
        MIN_TRAIN = {"daily": 60, "weekly": 30, "monthly": 24}
        DMAX = 2
        NSIM = 1500
        REFIT_EVERY = 10
        NSYNTH = {"daily": 400, "weekly": 800, "monthly": 80}
    else:
        ASSETS = list(TICKERS.keys())
        FREQS = ["daily", "weekly", "monthly"]
        MIN_TRAIN = {"daily": 120, "weekly": 60, "monthly": 36}
        DMAX = 5
        NSIM = 20000
        REFIT_EVERY = 10
        NSYNTH = {"daily": 2500, "weekly": 500, "monthly": 120}
    DIAG_NSIM = 1000 if fast else 5000

    print("=" * 64)
    print("SPGF FINANCIAL RETURNS -- UNIFIED EXPERIMENT (all 3 losses)")
    print("=" * 64)
    if fast:
        print("FAST MODE")
    if use_synthetic:
        print("SYNTHETIC DATA MODE")
    if sign_only:
        print("SIGN-ONLY MODE (skipping sign-mode baselines other than SPGF-Sign)")
    print(f"Assets: {', '.join(ASSETS)}")
    print(f"Horizons: {', '.join(FREQS)}")

    all_results = {}
    t0 = time.perf_counter()

    for ticker in ASSETS:
        all_results[ticker] = {}
        for freq in FREQS:
            returns, series_label = get_return_series(ticker, freq, use_synthetic,
                                                        n_override=NSYNTH.get(freq))
            if len(returns) < MIN_TRAIN[freq] + 20:
                print(f"Skipping {ticker}/{freq}: too few observations ({len(returns)})")
                continue
            bt = build_backtester(returns, series_label, MIN_TRAIN[freq], DMAX, NSIM,
                                   REFIT_EVERY, window_type, fallback_policy, sign_only=sign_only)
            bt.run(diagnostics=run_diag, diag_dmax=min(DMAX, 5), diag_nsim=DIAG_NSIM)
            all_results[ticker][freq] = bt.results
            print_full_leaderboard(bt.results, label=series_label)

    print(f"\nTotal wall time: {time.perf_counter() - t0:.1f}s")

    if not sign_only:
        print_cross_asset_summary(all_results, freqs=tuple(FREQS))
        print_cross_asset_rmse(all_results, freqs=tuple(FREQS))
        print_cross_asset_mase(all_results, freqs=tuple(FREQS))
        print_cross_asset_ir(all_results, freqs=tuple(FREQS))
        print_pnl_summary(all_results, freqs=tuple(FREQS))


if __name__ == "__main__":
    main()
