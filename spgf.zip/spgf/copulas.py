"""spgf.copulas: marginal model, 6 copula families, auto-selection."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import numpy as np
from scipy import stats
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import erf, erfinv

__all__ = ["MarginalModel", "Copula", "GaussianCopula", "StudentTCopula",
           "ClaytonCopula", "GumbelCopula", "FrankCopula", "EmpiricalCopula",
           "CopulaFitResult", "CopulaModel"]


class MarginalModel:
    def __init__(self, x, smoothing=1e-6):
        x = np.asarray(x, dtype=float)
        if x.ndim != 1:
            raise ValueError("x must be 1-D")
        if x.size < 2:
            raise ValueError("need at least 2 observations")
        self.sorted = np.sort(x)
        self.n = self.sorted.size
        self.smoothing = float(smoothing)
        ranks = (np.arange(1, self.n + 1) - 0.5) / self.n
        self.ranks = np.clip(ranks, smoothing, 1.0 - smoothing)

    def cdf(self, x):
        x = np.atleast_1d(np.asarray(x, dtype=float))
        u = np.interp(x, self.sorted, self.ranks, left=self.smoothing, right=1.0 - self.smoothing)
        return np.clip(u, self.smoothing, 1.0 - self.smoothing)

    def quantile(self, u):
        u = np.atleast_1d(np.asarray(u, dtype=float))
        u = np.clip(u, self.smoothing, 1.0 - self.smoothing)
        return np.interp(u, self.ranks, self.sorted)

    def __repr__(self):
        return f"MarginalModel(n={self.n}, range=[{self.sorted[0]:.4g}, {self.sorted[-1]:.4g}])"


class Copula:
    name = "abstract"

    def conditional_quantile(self, xi, uprev):
        raise NotImplementedError

    def cond_prob_positive(self, uprev, umedian):
        raise NotImplementedError

    def sample_chain(self, n, rng, u0=None):
        u = np.empty(n, dtype=float)
        u[0] = rng.uniform(1e-6, 1 - 1e-6) if u0 is None else float(u0)
        xis = rng.uniform(1e-9, 1 - 1e-9, size=n - 1)
        for i in range(1, n):
            u[i] = self.conditional_quantile(xis[i - 1], u[i - 1])
        return np.clip(u, 1e-9, 1 - 1e-9)


class GaussianCopula(Copula):
    name = "Gaussian"

    def __init__(self, rho):
        self.rho = float(np.clip(rho, -0.999, 0.999))

    @staticmethod
    def _Phi(x):
        return 0.5 * (1 + erf(x / np.sqrt(2)))

    @staticmethod
    def _Phi_inv(p):
        return np.sqrt(2) * erfinv(2 * np.clip(p, 1e-9, 1 - 1e-9) - 1)

    def conditional_quantile(self, xi, uprev):
        z = self._Phi_inv(uprev)
        sd = np.sqrt(max(1 - self.rho ** 2, 1e-12))
        return self._Phi(self.rho * z + sd * self._Phi_inv(xi))

    def cond_prob_positive(self, uprev, umedian):
        z = self._Phi_inv(float(uprev))
        zm = self._Phi_inv(umedian)
        sd = np.sqrt(max(1 - self.rho ** 2, 1e-12))
        return float(1 - self._Phi((zm - self.rho * z) / sd))

    def power(self, k):
        return GaussianCopula(self.rho ** k)


class StudentTCopula(Copula):
    name = "StudentT"

    def __init__(self, rho, df=4.0):
        self.rho = float(np.clip(rho, -0.999, 0.999))
        self.df = float(max(df, 2.01))
        self.tdist = stats.t(df=self.df)

    def conditional_quantile(self, xi, uprev):
        nu = self.df
        t1 = self.tdist.ppf(float(uprev))
        mu = self.rho * t1
        scale = np.sqrt((nu + t1 ** 2) * (1 - self.rho ** 2) / (nu + 1))
        return float(self.tdist.cdf(mu + scale * stats.t(df=nu + 1).ppf(float(xi))))

    def cond_prob_positive(self, uprev, umedian):
        nu = self.df
        t1 = self.tdist.ppf(float(uprev))
        tm = self.tdist.ppf(float(umedian))
        mu = self.rho * t1
        scale = np.sqrt((nu + t1 ** 2) * (1 - self.rho ** 2) / (nu + 1))
        return float(1 - stats.t(df=nu + 1).cdf((tm - mu) / max(scale, 1e-12)))

    def power(self, k):
        return StudentTCopula(self.rho ** k, df=self.df)


class ClaytonCopula(Copula):
    name = "Clayton"

    def __init__(self, theta):
        if theta <= 0:
            raise ValueError("theta > 0 required")
        self.theta = float(theta)

    def conditional_quantile(self, xi, uprev):
        th = self.theta
        u = float(np.clip(uprev, 1e-9, 1 - 1e-9))
        xi = float(np.clip(xi, 1e-9, 1 - 1e-9))
        S = xi ** (-th / (1.0 + th)) * u ** (-th) - u ** (-th) + 1.0
        vterm = max(S, 1e-12)
        return float(np.clip(vterm ** (-1.0 / th), 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, uprev, umedian):
        th = self.theta
        u = float(np.clip(uprev, 1e-9, 1 - 1e-9))
        um = float(np.clip(umedian, 1e-9, 1 - 1e-9))
        upow = u ** (-th - 1)
        denom = (u ** (-th) + um ** (-th) - 1) ** (-1 / th - 1)
        return float(1 - upow * denom)


class GumbelCopula(Copula):
    name = "Gumbel"

    def __init__(self, theta):
        if theta < 1:
            raise ValueError("theta >= 1 required")
        self.theta = float(theta)

    def conditional_quantile(self, xi, uprev):
        u = float(np.clip(uprev, 1e-9, 1 - 1e-9))
        th = self.theta

        def cond_cdf(v):
            v = float(np.clip(v, 1e-9, 1 - 1e-9))
            lu, lv = -np.log(u), -np.log(v)
            a = lu ** th + lv ** th
            C = np.exp(-a ** (1.0 / th))
            return C * (a ** (1.0 / th - 1.0)) * (lu ** (th - 1.0)) / u

        target = float(np.clip(xi, 1e-9, 1 - 1e-9))
        lo, hi = cond_cdf(1e-9), cond_cdf(1 - 1e-9)
        if target <= lo:
            return 1e-9
        if target >= hi:
            return 1 - 1e-9
        try:
            v = brentq(lambda vv: cond_cdf(vv) - target, 1e-9, 1 - 1e-9, xtol=1e-10)
        except ValueError:
            v = 0.5
        return float(np.clip(v, 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, uprev, umedian):
        u = float(np.clip(uprev, 1e-9, 1 - 1e-9))
        um = float(np.clip(umedian, 1e-9, 1 - 1e-9))
        th = self.theta
        lu, lum = -np.log(u), -np.log(um)
        a = lu ** th + lum ** th
        C = np.exp(-a ** (1.0 / th))
        cond_cdf = C * (a ** (1.0 / th - 1.0)) * (lu ** (th - 1.0)) / u
        return float(1 - cond_cdf)


class FrankCopula(Copula):
    name = "Frank"

    def __init__(self, theta):
        if abs(theta) < 1e-8:
            raise ValueError("theta != 0 required")
        self.theta = float(theta)

    def conditional_quantile(self, xi, uprev):
        th = self.theta
        eu = np.exp(-th * float(uprev))
        xi = float(np.clip(xi, 1e-9, 1 - 1e-9))
        num = xi * (1.0 - eu)
        den = 1.0 - xi + xi * eu
        den = den if abs(den) > 1e-300 else 1e-300
        v = -np.log(1.0 - num / den) / th
        return float(np.clip(v, 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, uprev, umedian):
        th = self.theta
        u = float(np.clip(uprev, 1e-9, 1 - 1e-9))
        um = float(np.clip(umedian, 1e-9, 1 - 1e-9))
        eu = np.exp(-th * u)
        ev = np.exp(-th * um)
        e1 = np.exp(-th)
        num = eu * ev - eu
        den = (e1 - 1) + (eu - 1) * (ev - 1)
        cond_cdf = num / den if den != 0 else 0.0
        return float(1 - cond_cdf)


class EmpiricalCopula(Copula):
    name = "Empirical"

    def __init__(self, u, v, k=None):
        self.u = np.asarray(u, dtype=float)
        self.v = np.asarray(v, dtype=float)
        self.n = self.u.size
        self.k = k if k is not None else max(20, int(np.sqrt(self.n)))

    def conditional_quantile(self, xi, uprev):
        dist = np.abs(self.u - uprev)
        idx = np.argpartition(dist, min(self.k, self.n - 1))[:self.k]
        neighbours = np.sort(self.v[idx])
        pos = float(xi) * (len(neighbours) - 1)
        lo = int(np.floor(pos))
        hi = min(lo + 1, len(neighbours) - 1)
        val = neighbours[lo] * (1 - (pos - lo)) + neighbours[hi] * (pos - lo)
        return float(np.clip(val, 1e-9, 1 - 1e-9))

    def cond_prob_positive(self, uprev, umedian):
        dist = np.abs(self.u - float(uprev))
        idx = np.argpartition(dist, min(self.k, self.n - 1))[:self.k]
        return float(np.mean(self.v[idx] > umedian))


@dataclass
class CopulaFitResult:
    family: str
    copula: Copula
    kendall_tau: float
    loglik: Optional[float] = None


class CopulaModel:
    def __init__(self, family="auto", studentt_df=4.0):
        self.family = family.lower()
        self.studentt_df = float(studentt_df)
        self.fit_result = None

    def fit(self, x, marginal=None):
        x = np.asarray(x, dtype=float)
        if marginal is None:
            marginal = MarginalModel(x)
        u_all = marginal.cdf(x)
        u, v = u_all[:-1], u_all[1:]
        tau, _ = stats.kendalltau(u, v)
        tau = 0.0 if not np.isfinite(tau) else float(np.clip(tau, -0.97, 0.97))
        family = self.family
        if family == "auto":
            family = self._select_family(u, v, tau)
        self.fit_result = self._fit_family(family, u, v, tau)
        return self

    def _select_family(self, u, v, tau):
        candidates = ["gaussian", "studentt", "frank", "empirical"]
        if tau > 0.02:
            candidates += ["clayton", "gumbel"]
        best_family, best_ll = "gaussian", -np.inf
        for fam in candidates:
            try:
                res = self._fit_family(fam, u, v, tau)
                score = -np.inf if res.loglik is None else res.loglik
                if score > best_ll:
                    best_ll, best_family = score, fam
            except Exception:
                continue
        return best_family

    def _fit_family(self, family, u, v, tau):
        if family == "gaussian":
            rho = float(np.clip(np.sin(tau * np.pi / 2.0), -0.999, 0.999))
            cop = GaussianCopula(rho)
        elif family == "studentt":
            rho = float(np.clip(np.sin(tau * np.pi / 2.0), -0.999, 0.999))
            cop = StudentTCopula(rho, df=self.studentt_df)
        elif family == "clayton":
            theta = max(2 * max(tau, 1e-3) / (1 - max(tau, 1e-3)), 1e-3)
            cop = ClaytonCopula(theta)
        elif family == "gumbel":
            theta = max(1.0 / (1.0 - max(tau, 1e-3)), 1.0 + 1e-6)
            cop = GumbelCopula(theta)
        elif family == "frank":
            theta = self._frank_theta_from_tau(tau)
            cop = FrankCopula(theta)
        elif family == "empirical":
            cop = EmpiricalCopula(u, v)
        else:
            raise ValueError(f"unknown family {family!r}")
        ll = self._pseudo_loglik(cop, u, v)
        return CopulaFitResult(family=family, copula=cop, kendall_tau=tau, loglik=ll)

    @staticmethod
    def _frank_theta_from_tau(tau):
        tau = float(np.clip(tau, -0.96, 0.96))
        if abs(tau) < 1e-6:
            return 1e-3

        def debye1(th):
            if abs(th) < 1e-8:
                return 1.0
            val, _ = quad(lambda t: t / np.expm1(t) if abs(t) > 1e-10 else 1.0, 0, th, limit=50)
            return val / th

        def tau_of_theta(th):
            if abs(th) < 1e-8:
                return 0.0
            return 1.0 - 4.0 / th * (1.0 - debye1(th))

        try:
            theta = brentq(lambda th: tau_of_theta(th) - tau, -40, 40, xtol=1e-6)
        except ValueError:
            theta = np.sign(tau) * 5.0
        return float(theta) if abs(theta) > 1e-3 else np.sign(tau) * 1e-3

    @staticmethod
    def _pseudo_loglik(cop, u, v):
        h = 1e-4
        try:
            with np.errstate(all="ignore"):
                q_lo = np.array([cop.conditional_quantile(max(uu - h, 1e-9), up) for uu, up in zip(v, u)])
                q_hi = np.array([cop.conditional_quantile(min(uu + h, 1 - 1e-9), up) for uu, up in zip(v, u)])
            dvdxi = np.clip(np.abs(q_hi - q_lo) / (2 * h), 1e-8, 1e8)
            ll = -np.log(dvdxi)
            ll = ll[np.isfinite(ll)]
            return float(np.mean(ll)) if ll.size > 0 else None
        except Exception:
            return None

    def sample_chain(self, n, rng=None, u0=None):
        if self.fit_result is None:
            raise RuntimeError("call .fit(x) first")
        rng = rng or np.random.default_rng()
        return self.fit_result.copula.sample_chain(n, rng, u0=u0)

    def cond_prob_positive(self, uprev, umedian):
        if self.fit_result is None:
            raise RuntimeError("call .fit(x) first")
        return self.fit_result.copula.cond_prob_positive(uprev, umedian)

    def __repr__(self):
        if self.fit_result is None:
            return f"CopulaModel(family={self.family!r}, unfitted)"
        r = self.fit_result
        return f"CopulaModel(family={r.family!r}, tau={r.kendall_tau:.3f})"
