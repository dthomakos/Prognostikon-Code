"""spgf.estimator: core SPGF grid-search estimator (MSE/MAE/SIGN)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import numpy as np
from .copulas import MarginalModel, CopulaModel

__all__ = ["SPGFParams", "SPGFEstimator", "sign_power", "ols", "l1_regression", "sign_accuracy_grid"]


def sign_power(x, g):
    return np.sign(x) * np.abs(x) ** g


def ols(z, y):
    zm, ym = z.mean(), y.mean()
    denom = np.dot(z - zm, z - zm)
    if denom < 1e-12:
        return float(ym), 0.0
    b = float(np.dot(y - ym, z - zm) / denom)
    return float(ym - b * zm), b


def l1_regression(z, y, maxiter=50, tol=1e-6):
    a, b = ols(z, y)
    eps = 1e-8 * (np.std(y) + 1e-8)
    for _ in range(maxiter):
        a_new = float(np.median(y - b * z))
        nz = np.abs(z) > eps
        if nz.sum() < 2:
            b_new = 0.0
        else:
            ratios = (y[nz] - a_new) / z[nz]
            weights = np.abs(z[nz])
            order = np.argsort(ratios)
            wcum = np.cumsum(weights[order])
            idx = min(np.searchsorted(wcum, wcum[-1] / 2.0), len(ratios) - 1)
            b_new = float(ratios[order[idx]])
        if abs(a_new - a) < tol and abs(b_new - b) < tol:
            a, b = a_new, b_new
            break
        a, b = a_new, b_new
    return a, b


def sign_accuracy_grid(y, z, tau_grid):
    sy = np.sign(y)
    sy[sy == 0] = 1
    best_acc, best_tau, best_sb = -np.inf, 0.0, 1.0
    for tau in tau_grid:
        sz = np.sign(z - tau)
        sz[sz == 0] = 1
        psi = float(np.mean(sy * sz))
        acc_pos = 0.5 + 0.5 * psi
        acc_neg = 0.5 - 0.5 * psi
        if acc_pos >= acc_neg and acc_pos > best_acc:
            best_acc, best_tau, best_sb = acc_pos, float(tau), 1.0
        elif acc_neg > acc_pos and acc_neg > best_acc:
            best_acc, best_tau, best_sb = acc_neg, float(tau), -1.0
    return best_tau, best_acc, best_sb


@dataclass
class SPGFParams:
    a: float
    b: float
    d: int
    g: float
    tau: Optional[float]
    loss: str
    value: float

    def forecast(self, xlag):
        z = np.sign(xlag) * abs(xlag) ** self.g
        return self.a + self.b * z


class SPGFEstimator:
    DEFAULT_G = np.array([0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0])

    def __init__(self, marginal, copula, dmax=4, ggrid=None, nsim=50000, tau_ngrid=200, rng=None):
        self.marginal = marginal
        self.copula = copula
        self.dmax = int(dmax)
        self.ggrid = np.asarray(ggrid if ggrid is not None else self.DEFAULT_G, dtype=float)
        self.nsim = int(nsim)
        self.tau_ngrid = int(tau_ngrid)
        self.rng = rng or np.random.default_rng()
        self.params_mse = None
        self.params_mae = None
        self.params_sign = None

    def fit(self, verbose=False):
        chain_len = self.nsim + self.dmax + 1
        u_chain = self.copula.sample_chain(chain_len, rng=self.rng)
        x_chain = self.marginal.quantile(u_chain)
        n = self.nsim
        best = {k: dict(value=np.inf if k != "SIGN" else -np.inf, params=None) for k in ("MSE", "MAE", "SIGN")}
        for d in range(self.dmax + 1):
            y = x_chain[d + 1: d + 1 + n]
            xlag = x_chain[:n]
            for g in self.ggrid:
                z = sign_power(xlag, g)
                am, bm = ols(z, y)
                mse_val = float(np.mean((y - am - bm * z) ** 2))
                if mse_val < best["MSE"]["value"]:
                    best["MSE"].update(value=mse_val, params=SPGFParams(a=am, b=bm, d=d, g=g, tau=None, loss="MSE", value=mse_val))
                al, bl = l1_regression(z, y)
                mae_val = float(np.mean(np.abs(y - al - bl * z)))
                if mae_val < best["MAE"]["value"]:
                    best["MAE"].update(value=mae_val, params=SPGFParams(a=al, b=bl, d=d, g=g, tau=None, loss="MAE", value=mae_val))
                tau_grid = np.quantile(z, np.linspace(0.02, 0.98, self.tau_ngrid))
                tau_s, acc_s, sb_s = sign_accuracy_grid(y, z, tau_grid)
                if acc_s > best["SIGN"]["value"]:
                    best["SIGN"].update(value=acc_s, params=SPGFParams(a=-sb_s * tau_s, b=sb_s, d=d, g=g, tau=tau_s, loss="SIGN", value=acc_s))
        self.params_mse = best["MSE"]["params"]
        self.params_mae = best["MAE"]["params"]
        sp = best["SIGN"]["params"]
        if sp is not None and self.params_mse is not None:
            sp.g = self.params_mse.g
        self.params_sign = sp
        return self

    def summary(self):
        return {"MSE": self.params_mse, "MAE": self.params_mae, "SIGN": self.params_sign}
