"""spgf.forecasters: all forecaster classes for demo and financial experiments."""
from __future__ import annotations
from typing import Optional
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import expit
from .copulas import MarginalModel, CopulaModel
from .estimator import SPGFEstimator, SPGFParams

__all__ = ["SPGFForecaster", "SPGFSignAdapter", "ThetaForecaster", "AR1Forecaster",
           "BuyAndHoldForecaster", "AR1SignForecaster", "BuyAndHoldSignForecaster",
           "MultiLagLogisticForecaster", "CopulaProbForecaster", "EnsembleSignForecaster"]


class SPGFForecaster:
    """Wraps the SPGF estimator for a single loss ('MSE', 'MAE', or 'SIGN').

    Exposes a level-mode API (predict) always. When loss='SIGN' it additionally
    exposes predict_sign/predict_prob so it can be used in sign-mode backtests too.
    This means the SAME class services level-mode (any real-valued series, any
    loss) and sign-mode (directional financial forecasting) use cases.
    """

    def __init__(self, loss="MSE", copula_family="auto", dmax=4, ggrid=None, nsim=50000, studentt_df=4.0):
        self.loss = loss.upper()
        if self.loss not in ("MSE", "MAE", "SIGN"):
            raise ValueError("loss must be one of 'MSE', 'MAE', 'SIGN'")
        self.copula_family = copula_family
        self.dmax = dmax
        self.ggrid = ggrid
        self.nsim = nsim
        self.studentt_df = studentt_df
        self.params = None
        self._copula = None

    def fit(self, xtrain, rng=None):
        xtrain = np.asarray(xtrain, dtype=float)
        rng = rng or np.random.default_rng()
        marginal = MarginalModel(xtrain)
        copula = CopulaModel(family=self.copula_family, studentt_df=self.studentt_df)
        copula.fit(xtrain, marginal=marginal)
        est = SPGFEstimator(marginal, copula, dmax=self.dmax, ggrid=self.ggrid, nsim=self.nsim, rng=rng)
        est.fit(verbose=False)
        self.params = est.summary()[self.loss]
        self._copula = copula
        return self

    def predict(self, xcontext):
        if self.params is None:
            raise RuntimeError("call .fit before .predict")
        p = self.params
        idx = -p.d - 1
        xlag = xcontext[idx] if abs(idx) <= len(xcontext) else xcontext[0]
        return p.forecast(float(xlag))

    def predict_sign(self, xcontext):
        f = self.predict(xcontext)
        return int(np.sign(f)) or 1

    def predict_prob(self, xcontext):
        return 0.75 if self.predict_sign(xcontext) > 0 else 0.25

    @property
    def fitted_params(self):
        return self.params


class SPGFSignAdapter:
    """Thin sign-only convenience wrapper around SPGFForecaster(loss='SIGN').

    Kept for backward compatibility with pure sign-mode pipelines; new code
    should prefer SPGFForecaster(loss='SIGN', ...) directly since it also
    supports .predict() for level-mode diagnostics.
    """

    def __init__(self, dmax=4, nsim=20000, copula_family="auto", ggrid=None, studentt_df=4.0):
        self._inner = SPGFForecaster(loss="SIGN", copula_family=copula_family, dmax=dmax, ggrid=ggrid, nsim=nsim, studentt_df=studentt_df)

    def fit(self, x, rng=None):
        self._inner.fit(x, rng=rng)
        return self

    def predict_sign(self, xcontext):
        return self._inner.predict_sign(xcontext)

    def predict_prob(self, xcontext):
        return self._inner.predict_prob(xcontext)

    @property
    def params(self):
        return self._inner.params


class ThetaForecaster:
    def __init__(self, alpha=None):
        self.alpha = alpha
        self.a = 0.0
        self.b = 0.0
        self.ses_next = 0.0
        self.n = 0
        self.alpha_fit = 0.2

    def fit(self, xtrain, rng=None):
        x = np.asarray(xtrain, dtype=float)
        n = len(x)
        self.n = n
        t = np.arange(1, n + 1, dtype=float)
        tm, xm = t.mean(), x.mean()
        b = np.dot(t - tm, x - xm) / np.dot(t - tm, t - tm)
        a = xm - b * tm
        self.a, self.b = float(a), float(b)
        theta2 = 2.0 * (x - (a + b * t))
        alpha = self.alpha if self.alpha is not None else self._fit_alpha(theta2)
        self.alpha_fit = float(alpha)
        level = float(theta2[0])
        for i in range(1, n):
            level = alpha * theta2[i] + (1.0 - alpha) * level
        self.ses_next = float(level)
        return self

    @staticmethod
    def _fit_alpha(y):
        def sse(alpha):
            level, s = y[0], 0.0
            for i in range(1, len(y)):
                s += (y[i] - level) ** 2
                level = alpha * y[i] + (1.0 - alpha) * level
            return s
        res = minimize_scalar(sse, bounds=(0.01, 0.99), method="bounded")
        return float(res.x)

    def predict(self, xcontext):
        return 0.5 * (self.a + self.b * (self.n + 1)) + 0.5 * self.ses_next


class AR1Forecaster:
    def __init__(self, demean=True):
        self.demean = demean
        self.a = 0.0
        self.b = 0.0

    def fit(self, xtrain, rng=None):
        x = np.asarray(xtrain, dtype=float)
        y, z = x[1:], x[:-1]
        if self.demean:
            zm, ym = z.mean(), y.mean()
            denom = np.dot(z - zm, z - zm)
            if denom < 1e-12:
                self.b, self.a = 0.0, float(y.mean())
            else:
                self.b = float(np.dot(y - ym, z - zm) / denom)
                self.a = float(ym - self.b * zm)
        else:
            denom = np.dot(z, z)
            self.b = float(np.dot(y, z) / denom) if denom > 1e-12 else 0.0
            self.a = 0.0
        return self

    def predict(self, xcontext):
        return self.a + self.b * float(xcontext[-1])


class BuyAndHoldForecaster:
    def fit(self, xtrain, rng=None):
        return self

    def predict(self, xcontext):
        return max(float(np.mean(xcontext)), 0.0)


class BuyAndHoldSignForecaster:
    def fit(self, x, rng=None):
        return self

    def predict_sign(self, xcontext):
        return 1

    def predict_prob(self, xcontext):
        return 0.75


class AR1SignForecaster:
    def __init__(self):
        self.a = 0.0
        self.b = 0.0

    def fit(self, x, rng=None):
        y, z = x[1:], x[:-1]
        zm, ym = z.mean(), y.mean()
        denom = np.dot(z - zm, z - zm)
        self.b = float(np.dot(y - ym, z - zm) / denom) if denom > 1e-12 else 0.0
        self.a = float(ym - self.b * zm)
        return self

    def predict_prob(self, xcontext):
        raw = self.a + self.b * float(np.atleast_1d(xcontext)[-1])
        return 0.75 if raw > 0 else 0.25

    def predict_sign(self, xcontext):
        raw = self.a + self.b * float(np.atleast_1d(xcontext)[-1])
        return 1 if raw >= 0 else -1


class MultiLagLogisticForecaster:
    def __init__(self, dmax=5, lam=1.0, maxiter=30, tol=1e-7):
        self.dmax = dmax
        self.lam = lam
        self.maxiter = maxiter
        self.tol = tol
        self.beta = None

    def _build_X(self, x):
        n = len(x)
        D = self.dmax
        rows = n - D - 1
        if rows <= 0:
            raise ValueError("series too short for dmax")
        X = np.ones((rows, D + 2))
        for d in range(D + 1):
            X[:, d + 1] = np.sign(x[D - d: D - d + rows])
        ybin = (x[D + 1: D + 1 + rows] > 0).astype(float)
        return X, ybin

    def fit(self, x, rng=None):
        X, y = self._build_X(x)
        _, p = X.shape
        beta = np.zeros(p)
        lam = self.lam
        for _ in range(self.maxiter):
            phat = np.clip(expit(X @ beta), 1e-9, 1 - 1e-9)
            W = phat * (1 - phat)
            grad = X.T @ (y - phat) - lam * beta
            grad[0] += lam * beta[0]
            H = -(X.T * W) @ X - lam * np.eye(p)
            H[0, 0] += lam
            try:
                delta = np.linalg.solve(H, grad)
            except np.linalg.LinAlgError:
                break
            beta -= delta
            if np.max(np.abs(delta)) < self.tol:
                break
        self.beta = beta
        return self

    def predict_prob(self, xcontext):
        D = self.dmax
        ctx = xcontext
        if len(ctx) < D + 1:
            ctx = np.concatenate([np.zeros(D + 1 - len(ctx)), ctx])
        feat = np.array([1.0] + [np.sign(float(ctx[-d - 1])) for d in range(D + 1)])
        return float(expit(self.beta @ feat)) if self.beta is not None else 0.5

    def predict_sign(self, xcontext):
        return 1 if self.predict_prob(xcontext) >= 0.5 else -1


class CopulaProbForecaster:
    def __init__(self, use_parametric=True, copula_family="auto", studentt_df=4.0):
        self.use_parametric = use_parametric
        self.copula_family = copula_family
        self.studentt_df = studentt_df
        self.model = None
        self.marginal = None
        self.u_median = 0.5

    def fit(self, x, rng=None):
        self.marginal = MarginalModel(x)
        family = self.copula_family if self.use_parametric else "empirical"
        self.model = CopulaModel(family=family, studentt_df=self.studentt_df)
        self.model.fit(x, marginal=self.marginal)
        self.u_median = float(self.marginal.cdf(np.array([0.0]))[0])
        return self

    def predict_prob(self, xcontext):
        xlast = float(xcontext[-1])
        u_last = float(self.marginal.cdf(np.array([xlast]))[0])
        return self.model.cond_prob_positive(u_last, self.u_median)

    def predict_sign(self, xcontext):
        return 1 if self.predict_prob(xcontext) >= 0.5 else -1


class EnsembleSignForecaster:
    def __init__(self, ar1, spgf, multilag, copulaprob):
        self.ar1 = ar1
        self.spgf = spgf
        self.multilag = multilag
        self.cp = copulaprob

    def predict_prob(self, xcontext):
        p1 = self.ar1.predict_prob(xcontext)
        p2 = self.spgf.predict_prob(xcontext)
        p3 = self.multilag.predict_prob(xcontext)
        p4 = self.cp.predict_prob(xcontext)
        return float(np.mean([p1, p2, p3, p4]))

    def predict_sign(self, xcontext):
        votes = [self.ar1.predict_sign(xcontext), self.spgf.predict_sign(xcontext),
                 self.multilag.predict_sign(xcontext), self.cp.predict_sign(xcontext)]
        total = sum(votes)
        if total > 0:
            return 1
        if total < 0:
            return -1
        return self.cp.predict_sign(xcontext)
