"""spgf.data: real (Yahoo Finance) and synthetic data generators."""
from __future__ import annotations
from typing import Optional, Tuple
import numpy as np

__all__ = ["TICKERS", "fetch_yfinance", "prices_to_returns", "synthetic_gjr_garch",
           "get_return_series", "dgp_ar1_gaussian", "dgp_nonlinear_student", "dgp_threshold_ar"]

TICKERS = {"SPY": "S&P 500 ETF", "QQQ": "Nasdaq-100 ETF", "EWZ": "Brazil ETF",
           "GLD": "Gold ETF", "AAPL": "Apple", "JPM": "JPMorgan"}


def fetch_yfinance(ticker, period="5y"):
    try:
        import yfinance as yf
        df = yf.Ticker(ticker).history(period=period, auto_adjust=True)
        if df is None or len(df) < 50:
            return None
        return df["Close"].dropna().values.astype(float)
    except Exception:
        return None


def prices_to_returns(prices, freq="daily"):
    logp = np.log(prices)
    if freq == "daily":
        return np.diff(logp)
    if freq == "weekly":
        return np.diff(logp[::5])
    if freq == "monthly":
        return np.diff(logp[::21])
    raise ValueError(f"unknown freq {freq!r}")


def synthetic_gjr_garch(n=2000, seed=0):
    rng = np.random.default_rng(seed)
    omega, alpha, gamma, beta, df = 2e-6, 0.04, 0.06, 0.90, 5.0
    scale = np.sqrt((df - 2) / df)
    h = np.ones(n) * omega / max(1 - alpha - 0.5 * gamma - beta, 1e-6)
    r = np.zeros(n)
    for t in range(1, n):
        ind = float(r[t - 1] < 0)
        h[t] = omega + (alpha + gamma * ind) * r[t - 1] ** 2 + beta * h[t - 1]
        r[t] = np.sqrt(h[t]) * rng.standard_t(df) * scale
    return r


def get_return_series(ticker, freq, use_synthetic, n_override=None):
    if not use_synthetic:
        prices = fetch_yfinance(ticker, period="5y")
        if prices is not None and len(prices) > 100:
            ret = prices_to_returns(prices, freq)
            label = TICKERS.get(ticker, ticker)
            return ret, f"{ticker} ({label}) -- Yahoo Finance, {freq}"
    nmap = {"daily": 2500, "weekly": 500, "monthly": 120}
    seed_map = {t: i * 7 for i, t in enumerate(TICKERS)}
    n = n_override if n_override is not None else nmap.get(freq, 2500)
    seed = seed_map.get(ticker, 0) + {"daily": 0, "weekly": 3, "monthly": 7}.get(freq, 0)
    r = synthetic_gjr_garch(n=n, seed=seed)
    if freq == "weekly":
        r = np.array([r[i:i + 5].sum() for i in range(0, len(r) - 5, 5)])
    elif freq == "monthly":
        r = np.array([r[i:i + 21].sum() for i in range(0, len(r) - 21, 21)])
    label = TICKERS.get(ticker, ticker)
    return r, f"{ticker} ({label}) -- Synthetic GJR-GARCH, {freq}"


def dgp_ar1_gaussian(n, rho=0.55, sigma=1.0, seed=0):
    rng = np.random.default_rng(seed)
    x = np.zeros(n)
    x[0] = rng.normal(0, sigma / np.sqrt(max(1 - rho ** 2, 1e-6)))
    for t in range(1, n):
        x[t] = rho * x[t - 1] + rng.normal(0, sigma)
    return x


def dgp_nonlinear_student(n, rho=0.60, df=4.0, gtrue=0.5, seed=1):
    rng = np.random.default_rng(seed)
    scale = np.sqrt((df - 2) / df)
    x = np.zeros(n)
    for t in range(1, n):
        z = np.sign(x[t - 1]) * abs(x[t - 1]) ** gtrue
        x[t] = rho * z + rng.standard_t(df) * scale
    return x


def dgp_threshold_ar(n, rho_lo=0.7, rho_hi=-0.2, thresh=0.0, seed=2):
    rng = np.random.default_rng(seed)
    x = np.zeros(n)
    for t in range(1, n):
        rho = rho_lo if x[t - 1] > thresh else rho_hi
        x[t] = rho * x[t - 1] + rng.normal(0, 1.0)
    return x


def load_series_from_csv(path, column=None):
    """Load an arbitrary non-financial (or financial) univariate time series from CSV.

    If `column` is given, uses that column; otherwise uses the last numeric column.
    Returns a 1-D float array. This is the generic entry point for using the SPGF
    package on ANY real-valued series, not just financial returns.
    """
    import csv
    rows = []
    with open(path, newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        col_idx = header.index(column) if column is not None else len(header) - 1
        for row in reader:
            if not row:
                continue
            try:
                rows.append(float(row[col_idx]))
            except (ValueError, IndexError):
                continue
    if len(rows) < 10:
        raise ValueError(f"too few valid numeric rows ({len(rows)}) in {path!r}")
    return np.asarray(rows, dtype=float)
