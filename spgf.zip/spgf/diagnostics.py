"""spgf.diagnostics: Appendix-A diagnostic test suite."""
from __future__ import annotations
from typing import Dict
import numpy as np
from scipy.stats import norm, chi2
from .copulas import MarginalModel, CopulaModel

__all__ = ["dno_decay_test", "hit_rate_bound_test", "mse_mae_slope_test", "jonckheere_terpstra_test", "run_diagnostics"]


def dno_decay_test(x, dmax=5, nsim=20000, rng_seed=42) -> Dict[str, float]:
    T = len(x)
    if T < dmax + 2:
        return {"stat": np.nan, "pvalue": np.nan, "df": dmax}
    marginal = MarginalModel(x)
    copula_model = CopulaModel(family="auto").fit(x, marginal=marginal)
    rng = np.random.default_rng(rng_seed)
    chain_len = nsim + dmax + 1
    u_chain = copula_model.sample_chain(chain_len, rng)
    x_chain = marginal.quantile(u_chain)
    kappas_obs, kappas_model = [], []
    for d in range(1, dmax + 1):
        y = x[d:]
        z = x[:-d]
        n = min(len(y), len(z))
        if n < 5:
            continue
        kappas_obs.append(float(np.mean(np.sign(y[:n]) * np.sign(z[:n]))))
        ym = x_chain[d: d + nsim]
        zm = x_chain[:nsim]
        kappas_model.append(float(np.mean(np.sign(ym) * np.sign(zm))))
    if len(kappas_obs) < 2:
        return {"stat": np.nan, "pvalue": np.nan, "df": dmax}
    diff = np.array(kappas_obs) - np.array(kappas_model)
    n_eff = max(T - dmax, 10)
    var_est = 1.0 / n_eff
    W = float(np.sum(diff ** 2) / var_est)
    df = len(diff)
    pv = float(chi2.sf(W, df=df))
    return {"stat": W, "pvalue": pv, "df": df}


def hit_rate_bound_test(hit_rate, kappa1, n) -> Dict[str, float]:
    if n <= 1:
        return {"stat": np.nan, "pvalue": np.nan}
    bound = 0.5 + 0.5 * abs(kappa1)
    se = np.sqrt(max(bound * (1 - bound), 1e-9) / n)
    if se <= 0:
        return {"stat": np.nan, "pvalue": np.nan}
    z = (hit_rate - bound) / se
    pv = float(norm.sf(z))
    return {"stat": float(z), "pvalue": pv}


def mse_mae_slope_test(y, z) -> Dict[str, float]:
    n = len(y)
    if n < 10:
        return {"stat": np.nan, "pvalue": np.nan}
    zm, ym = z.mean(), y.mean()
    denom = np.dot(z - zm, z - zm)
    if denom < 1e-12:
        return {"stat": np.nan, "pvalue": np.nan}
    b_ols = float(np.dot(y - ym, z - zm) / denom)
    resid = y - (ym - b_ols * zm) - b_ols * z
    sigma2 = float(np.var(resid))
    var_b_ols = sigma2 / denom
    med_resid = np.median(np.abs(resid)) + 1e-9
    f0 = 1.0 / (2 * med_resid)
    var_b_mae = 1.0 / (4 * f0 ** 2 * denom) if denom > 0 else np.inf
    ratios = (y - ym) / np.where(np.abs(z - zm) < 1e-9, np.nan, (z - zm))
    ratios = ratios[np.isfinite(ratios)]
    b_mae = float(np.median(ratios)) if ratios.size > 0 else b_ols
    var_diff = max(var_b_mae - var_b_ols, 1e-12)
    stat = float((b_mae - b_ols) ** 2 / var_diff)
    pv = float(chi2.sf(stat, df=1))
    return {"stat": stat, "pvalue": pv}


def jonckheere_terpstra_test(z, y, n_groups=5) -> Dict[str, float]:
    n = len(z)
    if n < 4 * n_groups:
        return {"stat": np.nan, "pvalue": np.nan}
    order = np.argsort(z)
    groups = np.array_split(order, n_groups)
    group_vals = [y[g] for g in groups if len(g) > 0]
    k = len(group_vals)
    if k < 2:
        return {"stat": np.nan, "pvalue": np.nan}
    J = 0
    for i in range(k):
        for j in range(i + 1, k):
            gi, gj = group_vals[i], group_vals[j]
            J += np.sum(gj[:, None] > gi[None, :]) - np.sum(gj[:, None] < gi[None, :])
    ns = [len(g) for g in group_vals]
    N = sum(ns)
    var_J = (N ** 2 * (2 * N + 3) - sum(n_i ** 2 * (2 * n_i + 3) for n_i in ns)) / 18.0
    if var_J <= 0:
        return {"stat": np.nan, "pvalue": np.nan}
    z_stat = float(J / np.sqrt(var_J))
    pv = float(norm.sf(z_stat))
    return {"stat": z_stat, "pvalue": pv}


def run_diagnostics(x, dmax=5, nsim=20000, rng_seed=42) -> Dict[str, Dict[str, float]]:
    results = {}
    results["DNO"] = dno_decay_test(x, dmax=dmax, nsim=nsim, rng_seed=rng_seed)
    if len(x) > 2:
        kappa1 = float(np.mean(np.sign(x[1:]) * np.sign(x[:-1])))
    else:
        kappa1 = 0.0
    hit_rate = 0.5 + 0.5 * abs(kappa1)
    results["HitBound"] = hit_rate_bound_test(hit_rate, kappa1, len(x))
    if len(x) > 1:
        y, z = x[1:], x[:-1]
        results["MSEvsMAE"] = mse_mae_slope_test(y, z)
        if len(x) >= 20:
            results["Monotonicity"] = jonckheere_terpstra_test(z, y)
        else:
            results["Monotonicity"] = {"stat": np.nan, "pvalue": np.nan}
    else:
        results["MSEvsMAE"] = {"stat": np.nan, "pvalue": np.nan}
        results["Monotonicity"] = {"stat": np.nan, "pvalue": np.nan}
    return results
