"""spgf.stats_tests: PT test and HLN-corrected DM tests."""
from __future__ import annotations
from typing import Tuple
import numpy as np
from scipy import stats

__all__ = ["pesaran_timmermann_test", "diebold_mariano_test", "diebold_mariano_sign"]


def pesaran_timmermann_test(actual, forecast) -> Tuple[float, float]:
    actual = np.asarray(actual, dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    n = len(actual)
    if n == 0:
        return 0.0, 1.0
    sa = (actual > 0).astype(float)
    sf = (forecast > 0).astype(float)
    py, pf = sa.mean(), sf.mean()
    pc = py * pf + (1 - py) * (1 - pf)
    phat = np.mean(sa == sf)
    var_pc = ((2 * py - 1) ** 2 * pf * (1 - pf) + (2 * pf - 1) ** 2 * py * (1 - py)) / max(n, 1)
    var_phat = pc * (1 - pc) / max(n, 1)
    var_diff = var_phat - var_pc
    if var_diff <= 0:
        return 0.0, 1.0
    pt_stat = (phat - pc) / np.sqrt(var_diff)
    return float(pt_stat), float(2 * stats.norm.sf(abs(pt_stat)))


def diebold_mariano_test(e1, e2, loss="MSE", h=1, correction=True) -> Tuple[float, float]:
    e1 = np.asarray(e1, dtype=float)
    e2 = np.asarray(e2, dtype=float)
    loss_u = loss.upper()
    if loss_u == "MSE":
        d = e1 ** 2 - e2 ** 2
    elif loss_u == "MAE":
        d = np.abs(e1) - np.abs(e2)
    elif loss_u == "SIGN":
        d = e1 - e2
    else:
        raise ValueError("loss must be MSE, MAE, or SIGN")
    T = len(d)
    if T < 5:
        return 0.0, 1.0
    dbar = d.mean()
    bw = max(1, int(np.ceil(T ** (1.0 / 3.0))))
    g0 = np.var(d, ddof=0)
    gsum = sum(2 * (1 - j / (bw + 1.0)) * np.cov(d[j:], d[:-j], ddof=0)[0, 1] for j in range(1, bw + 1))
    var_d = (g0 + gsum) / T
    if var_d <= 0:
        return 0.0, 1.0
    dm = dbar / np.sqrt(var_d)
    if correction:
        dm *= np.sqrt((T + 1 - 2 * h + h * (h - 1) / T) / T)
        pv = float(2.0 * stats.t(df=T - 1).sf(abs(dm)))
    else:
        pv = float(2.0 * stats.norm.sf(abs(dm)))
    return float(dm), pv


def diebold_mariano_sign(hits1, hits2) -> Tuple[float, float]:
    return diebold_mariano_test(np.asarray(hits1, dtype=float), np.asarray(hits2, dtype=float), loss="SIGN")
