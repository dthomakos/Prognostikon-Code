"""spgf.reporting: leaderboard, DM-table, diagnostic and cross-asset printers."""
from __future__ import annotations
from typing import Dict, Callable, Sequence
import numpy as np
from .backtest import Results
from .stats_tests import diebold_mariano_test, diebold_mariano_sign

__all__ = ["print_statistical_leaderboard", "print_economic_leaderboard",
           "print_dm_statistical_table", "print_dm_sign_table", "print_diagnostic_table",
           "print_full_leaderboard", "cross_asset_table", "print_cross_asset_summary",
           "print_cross_asset_rmse", "print_cross_asset_mase", "print_cross_asset_ir", "print_pnl_summary"]

DEFAULT_METHODS = ["BuyHold", "AR1-Sign", "SPGF-MSE", "SPGF-MAE", "SPGF-Sign",
                    "MultiLag-Log", "CopulaProb", "Ensemble"]


def _naive_mae(results):
    for res in results.values():
        if res.naive_mae is not None:
            return float(res.naive_mae)
    return 1.0


def print_statistical_leaderboard(results, label=""):
    if not results:
        return
    nm = _naive_mae(results)
    rows = [(name, res.summary(nm)) for name, res in results.items()]
    rows.sort(key=lambda r: r[1]["RMSE"])
    sep = "-" * 86
    print(sep)
    print(f"Statistical metrics: {label}" if label else "Statistical metrics")
    print(sep)
    print(f"{'Forecaster':16}{'N':>5}{'MSE':>12}{'RMSE':>10}{'MAE':>10}{'MASE':>8}{'HitRate':>9}")
    print(sep)
    for name, s in rows:
        mase_str = f"{s['MASE']:8.4f}" if np.isfinite(s["MASE"]) else f"{'NA':>8}"
        print(f"{name:16}{s['N']:5d}{s['MSE']:12.6f}{s['RMSE']:10.6f}{s['MAE']:10.6f}{mase_str}{s['HitRate']:9.4f}")
    print(sep)


def print_economic_leaderboard(results, label=""):
    if not results:
        return
    nm = _naive_mae(results)
    rows = [(name, res.summary(nm)) for name, res in results.items()]
    rows.sort(key=lambda r: -r[1]["HitRate"])
    sep = "-" * 96
    print(sep)
    print(f"Economic metrics: {label}" if label else "Economic metrics")
    print(sep)
    hdr = f"{'Forecaster':16}{'N':>5}{'HitRate':>9}{'PT-stat':>9}{'PT-p':>9}{'IR':>9}{'PnL(x)':>9}{'FB':>5}"
    print(hdr)
    print(sep)
    for name, s in rows:
        star = "**" if s["PT-pvalue"] < 0.01 else ("*" if s["PT-pvalue"] < 0.05 else "")
        ir = s.get("IR", float("nan"))
        pnl = s.get("TotalPnL", float("nan"))
        row = (f"{name:16}{s['N']:5d}{s['HitRate']:9.4f}{s['PT-stat']:9.3f}{s['PT-pvalue']:8.4f}{star:2}"
               f"{ir:9.4f}{pnl:8.3f}x{s['Fallbacks']:5d}")
        print(row)
    print(sep)


def print_dm_statistical_table(results, loss="MSE"):
    if not results:
        return
    names = list(results.keys())
    errors = {name: np.asarray(res.errors) for name, res in results.items()}
    print(f"DM test ({loss.upper()} loss, HLN-corrected)")
    print(" " * 16 + "".join(f"{n:>10}" for n in names))
    for n1 in names:
        row = f"{n1:16}"
        for n2 in names:
            if n1 == n2:
                row += f"{'---':>10}"
            else:
                dm, pv = diebold_mariano_test(errors[n1], errors[n2], loss=loss.upper())
                sig = "**" if pv < 0.01 else ("*" if pv < 0.05 else "")
                row += f"{('+' if dm > 0 else '-') + f'{pv:.4f}' + sig:>10}"
        print(row)
    print()


def print_dm_sign_table(results):
    if not results:
        return
    names = list(results.keys())
    hits = {name: res.hit_array for name, res in results.items()}
    print("DM test (SIGN loss, HLN-corrected)")
    print(" " * 16 + "".join(f"{n:>10}" for n in names))
    for n1 in names:
        row = f"{n1:16}"
        for n2 in names:
            if n1 == n2:
                row += f"{'---':>10}"
            else:
                dm, pv = diebold_mariano_sign(hits[n1], hits[n2])
                sig = "**" if pv < 0.01 else ("*" if pv < 0.05 else "")
                row += f"{('+' if dm > 0 else '-') + f'{pv:.4f}' + sig:>10}"
        print(row)
    print()


def print_diagnostic_table(results):
    for name, res in results.items():
        diag_summary = res.diagnostic_summary()
        if not diag_summary:
            continue
        print("=" * 64)
        print(f"DIAGNOSTIC TESTS (averaged over rolling windows): {name}")
        print("=" * 64)
        print(f"{'Test':16}{'MeanStat':>12}{'MeanP':>12}{'Rej5%':>10}{'Count':>8}")
        print("-" * 64)
        for test_name, s in diag_summary.items():
            print(f"{test_name:16}{s['mean_stat']:12.4f}{s['mean_pvalue']:12.4f}{s['rej_5pct']:10.3f}{s['count']:8d}")
        print("=" * 64)


def print_full_leaderboard(results, label=""):
    print_statistical_leaderboard(results, label=label)
    print_economic_leaderboard(results, label=label)
    print_dm_statistical_table(results, loss="MSE")
    print_dm_statistical_table(results, loss="MAE")
    print_dm_sign_table(results)
    print_diagnostic_table(results)


def cross_asset_table(all_results, methods, freqs, metric_fn, title):
    print("=" * 76)
    print(title)
    print("=" * 76)
    for freq in freqs:
        print(f"--- Horizon: {freq.upper()} ---")
        print(f"{'Asset':10}" + "".join(f"{m:>12}" for m in methods))
        print("-" * 74)
        for ticker, freq_dict in all_results.items():
            if freq not in freq_dict or not freq_dict[freq]:
                continue
            res = freq_dict[freq]
            row = f"{ticker:10}"
            for m in methods:
                row += f"{metric_fn(res[m], m):>12}" if m in res else f"{'NA':>12}"
            print(row)


def print_cross_asset_summary(all_results, methods=None, freqs=("daily", "weekly", "monthly")):
    methods = methods or DEFAULT_METHODS
    def fn(res, m):
        hr = res.hit_rate
        ptp = res.pt_test()[1]
        sig = "*" if ptp < 0.10 else ""
        return f"{hr:.4f}{sig}"
    cross_asset_table(all_results, methods, freqs, fn, "CROSS-ASSET DIRECTIONAL ACCURACY (HitRate, * = PT-test p<0.10)")


def print_cross_asset_rmse(all_results, methods=None, freqs=("daily", "weekly", "monthly")):
    methods = methods or DEFAULT_METHODS
    cross_asset_table(all_results, methods, freqs, lambda res, m: f"{res.rmse:.5f}", "CROSS-ASSET RMSE (level-scaled forecast errors)")


def print_cross_asset_mase(all_results, methods=None, freqs=("daily", "weekly", "monthly")):
    methods = methods or DEFAULT_METHODS
    def fn(res, m):
        return f"{res.mase():.5f}"
    cross_asset_table(all_results, methods, freqs, fn, "CROSS-ASSET MASE (naive-scaled absolute forecast errors)")


def print_cross_asset_ir(all_results, methods=None, freqs=("daily", "weekly", "monthly")):
    methods = methods or DEFAULT_METHODS
    cross_asset_table(all_results, methods, freqs, lambda res, m: f"{res.information_ratio:.4f}", "CROSS-ASSET INFORMATION RATIO (long-short sign strategy)")


def print_pnl_summary(all_results, methods=None, freqs=("daily", "weekly", "monthly")):
    methods = methods or DEFAULT_METHODS
    def fn(res, m):
        pnl = res.summary()["TotalPnL"]
        return f"{pnl:.3f}x"
    cross_asset_table(all_results, methods, freqs, fn, "LONG-SHORT CUMULATIVE P&L (gross, 1x leverage, no transaction costs)")
