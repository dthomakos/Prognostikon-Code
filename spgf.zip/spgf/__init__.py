"""SPGF: Sign-Power Generalized Forecast -- unified package."""
from . import copulas, estimator, forecasters, diagnostics, backtest, reporting, data, stats_tests
__version__ = "5.1.0-unified"
