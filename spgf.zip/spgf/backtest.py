"""spgf.backtest: generalized rolling/expanding backtest engine."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import numpy as np
from .stats_tests import pesaran_timmermann_test
from .diagnostics import run_diagnostics

__all__ = ["Results", "RollingBacktester"]


@dataclass
class Results:
    name: str
    mode: str = "level"
    forecasts: List[float] = field(default_factory=list)
    predicted_signs: List[int] = field(default_factory=list)
    predicted_probs: List[float] = field(default_factory=list)
    actuals: List[float] = field(default_factory=list)
    errors: List[float] = field(default_factory=list)
    fallback_count: int = 0
    failure_messages: List[str] = field(default_factory=list)
    diagnostics: List[Dict[str, Dict[str, float]]] = field(default_factory=list)
    naive_mae: float = 1.0

    def append_level(self, forecast, actual):
        self.forecasts.append(float(forecast))
        self.actuals.append(float(actual))
        self.errors.append(float(actual) - float(forecast))

    def append_sign(self, pred_sign, pred_prob, actual, sigma_hat=1.0):
        self.predicted_signs.append(int(pred_sign))
        self.predicted_probs.append(float(pred_prob))
        self.actuals.append(float(actual))
        level = (2.0 * float(pred_prob) - 1.0) * float(sigma_hat)
        self.errors.append(float(actual) - level)

    def add_diagnostics(self, diag):
        self.diagnostics.append(diag)

    @property
    def n(self):
        return len(self.actuals)

    @property
    def mse(self):
        e = np.asarray(self.errors)
        return float(np.mean(e ** 2)) if e.size else float("nan")

    @property
    def rmse(self):
        return float(np.sqrt(self.mse))

    @property
    def mae(self):
        e = np.asarray(self.errors)
        return float(np.mean(np.abs(e))) if e.size else float("nan")

    def mase(self, naive_mae=None):
        nm = naive_mae if naive_mae is not None else self.naive_mae
        return self.mae / nm if nm > 0 else float("nan")

    @property
    def actual_signs(self):
        a = np.asarray(self.actuals, dtype=float)
        s = np.sign(a)
        s[s == 0] = 1
        return s

    @property
    def hit_rate(self):
        if self.n == 0:
            return float("nan")
        if self.mode == "sign":
            pred = np.asarray(self.predicted_signs, dtype=float)
        else:
            pred = np.sign(np.asarray(self.forecasts, dtype=float))
            pred[pred == 0] = 1
        return float(np.mean(pred == self.actual_signs))

    @property
    def hit_array(self):
        if self.mode == "sign":
            pred = np.asarray(self.predicted_signs, dtype=float)
        else:
            pred = np.sign(np.asarray(self.forecasts, dtype=float))
            pred[pred == 0] = 1
        return (pred == self.actual_signs).astype(float)

    @property
    def strategy_returns(self):
        """Long-short P&L using the SIGN of the forecast, regardless of mode.

        For 'sign' mode this uses predicted_signs directly. For 'level' mode
        (e.g. SPGF-MSE, SPGF-MAE) this derives a sign from the level forecast,
        so ANY level forecaster can be scored economically too (IR, PnL),
        not just forecasters that natively expose predict_sign.
        """
        if self.n == 0:
            return np.array([])
        if self.mode == "sign":
            pred_sign = np.asarray(self.predicted_signs, dtype=float)
        else:
            pred_sign = np.sign(np.asarray(self.forecasts, dtype=float))
            pred_sign[pred_sign == 0] = 1
        return pred_sign * np.asarray(self.actuals, dtype=float)

    @property
    def cumulative_pnl(self):
        sr = self.strategy_returns
        if sr.size == 0:
            return np.array([1.0])
        return np.cumprod(1.0 + np.clip(sr, -0.5, 0.5))

    @property
    def information_ratio(self):
        sr = self.strategy_returns
        if len(sr) < 2:
            return float("nan")
        return float(np.mean(sr) / (np.std(sr, ddof=1) + 1e-10))

    def pt_test(self):
        if self.mode == "sign":
            forecast = np.asarray(self.predicted_signs, dtype=float)
        else:
            forecast = np.asarray(self.forecasts, dtype=float)
        return pesaran_timmermann_test(np.asarray(self.actuals, dtype=float), forecast)

    def diagnostic_summary(self):
        if not self.diagnostics:
            return {}
        agg = {}
        for test_name in self.diagnostics[0].keys():
            stats_ = [d[test_name]["stat"] for d in self.diagnostics if not np.isnan(d[test_name]["stat"])]
            pvals = [d[test_name]["pvalue"] for d in self.diagnostics if not np.isnan(d[test_name]["pvalue"])]
            if stats_:
                agg[test_name] = {
                    "mean_stat": float(np.mean(stats_)),
                    "mean_pvalue": float(np.mean(pvals)) if pvals else float("nan"),
                    "rej_5pct": float(np.mean(np.array(pvals) < 0.05)) if pvals else float("nan"),
                    "count": len(stats_),
                }
        return agg

    def summary(self, naive_mae=None):
        pt_stat, pt_pv = self.pt_test()
        out = {"N": self.n, "MSE": self.mse, "RMSE": self.rmse, "MAE": self.mae,
               "MASE": self.mase(naive_mae), "HitRate": self.hit_rate,
               "PT-stat": pt_stat, "PT-pvalue": pt_pv, "Fallbacks": self.fallback_count,
               "IR": self.information_ratio,
               "TotalPnL": float(self.cumulative_pnl[-1]) if self.n > 0 else float("nan")}
        return out


class RollingBacktester:
    def __init__(self, x, min_train=100, window_type="expanding", rng_seed=42,
                 verbose=True, fallback_policy="mean", label=""):
        self.x = np.asarray(x, dtype=float)
        self.T = len(self.x)
        if min_train < 10 or min_train >= self.T:
            raise ValueError("min_train must satisfy 10 <= min_train < T")
        self.min_train = int(min_train)
        self.window_type = window_type.lower()
        self.rng_seed = int(rng_seed)
        self.verbose = verbose
        self.fallback_policy = fallback_policy.lower()
        self.label = label
        self.forecasters: Dict[str, Any] = {}
        self.refit_every: Dict[str, int] = {}
        self.modes: Dict[str, str] = {}
        self.results: Dict[str, Results] = {}
        self.diagnostic_targets: List[str] = []
        self.naive_mae = 1.0
        self.ran = False

    def add_forecaster(self, name, forecaster, refit_every=1, mode=None, run_diagnostics_here=False):
        if name in self.forecasters:
            raise ValueError(f"{name!r} already registered")
        if mode is None:
            mode = "sign" if hasattr(forecaster, "predict_sign") else "level"
        self.forecasters[name] = forecaster
        self.refit_every[name] = max(1, int(refit_every))
        self.modes[name] = mode
        self.results[name] = Results(name=name, mode=mode)
        if run_diagnostics_here:
            self.diagnostic_targets.append(name)
        return self

    def _fallback(self, xtrain, mode):
        if self.fallback_policy == "raise":
            raise RuntimeError("forecast failure with fallback_policy='raise'")
        if mode == "level":
            if self.fallback_policy == "zero":
                return 0.0
            return float(np.mean(xtrain))
        if self.fallback_policy == "zero":
            return 1, 0.5
        s = 1 if np.mean(xtrain) >= 0 else -1
        p = 0.75 if s > 0 else 0.25
        return s, p

    def run(self, diagnostics=False, diag_dmax=5, diag_nsim=5000):
        if not self.forecasters:
            raise RuntimeError("no forecasters registered")
        x = self.x
        n_eval = self.T - self.min_train
        self.naive_mae = float(np.mean(np.abs(np.diff(x[:self.min_train])))) or 1.0
        if self.naive_mae <= 1e-12:
            self.naive_mae = 1.0
        if self.verbose:
            print("=" * 64)
            print(self.label or "Backtest")
            print(f"T={self.T} min_train={self.min_train} eval={n_eval} window={self.window_type} n_forecasters={len(self.forecasters)}")
            print("=" * 64)
        fitted_once = {name: False for name in self.forecasters}
        for step, t in enumerate(range(self.min_train, self.T)):
            if self.window_type == "expanding":
                xtrain = x[:t]
            else:
                xtrain = x[max(0, t - self.min_train):t]
            actual = float(x[t])
            sigma_hat = float(np.std(xtrain, ddof=1)) if len(xtrain) > 1 else 1.0
            rng = np.random.default_rng((self.rng_seed, step))
            for name, fcast in self.forecasters.items():
                mode = self.modes[name]
                res = self.results[name]
                do_refit = (step % self.refit_every[name] == 0) or not fitted_once[name]
                try:
                    if do_refit:
                        try:
                            fcast.fit(xtrain, rng=rng)
                        except TypeError:
                            fcast.fit(xtrain)
                        fitted_once[name] = True
                        if diagnostics and name in self.diagnostic_targets and len(xtrain) > diag_dmax + 5:
                            try:
                                diag = run_diagnostics(xtrain, dmax=diag_dmax, nsim=diag_nsim, rng_seed=self.rng_seed + step)
                                res.add_diagnostics(diag)
                            except Exception as e:
                                if self.verbose:
                                    print(f"  [diagnostics error @ step {step}] {e!r}")
                    if mode == "level":
                        f = float(fcast.predict(xtrain))
                        if not np.isfinite(f):
                            raise ValueError("non-finite forecast")
                        res.append_level(f, actual)
                    else:
                        xcontext = x[max(0, t - 32):t]
                        s = fcast.predict_sign(xcontext)
                        p = fcast.predict_prob(xcontext)
                        if not (np.isfinite(s) and np.isfinite(p)):
                            raise ValueError("non-finite output")
                        res.append_sign(s, p, actual, sigma_hat)
                except Exception as exc:
                    res.fallback_count += 1
                    if len(res.failure_messages) < 5:
                        res.failure_messages.append(repr(exc))
                    if mode == "level":
                        f = self._fallback(xtrain, "level")
                        res.append_level(f, actual)
                    else:
                        s, p = self._fallback(xtrain, "sign")
                        res.append_sign(s, p, actual, sigma_hat)
            if self.verbose and (step % max(1, n_eval // 8) == 0 or step == n_eval - 1):
                pct = 100 * (step + 1) / n_eval
                print(f"  step {step + 1:>6}/{n_eval} ({pct:5.1f}%)", end="\r", flush=True)
        if self.verbose:
            print()
            print("Backtest complete.")
        for res in self.results.values():
            res.naive_mae = self.naive_mae
        self.ran = True
        return self

    def get_results(self, name):
        if name not in self.results:
            raise KeyError(f"{name!r} not registered")
        return self.results[name]

    def check_ran(self):
        if not self.ran:
            raise RuntimeError("call .run() first")
